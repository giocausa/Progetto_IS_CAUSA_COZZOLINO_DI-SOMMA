/**
 * 
 */
/**
 * 
 */
module ProgettoIS3 {
	requires java.desktop;
    requires java.sql;
    exports test to junit;
    requires junit;

}