package Control;

import Entity.*;

import java.util.ArrayList;

public class GestioneTask {

    public static boolean CreaTask(Docente d, String tit, String desc, int p,int g,int m, int a){
        if (!Cercatask(tit)){
            Data da =new Data(g,m,a);
            Task t = new Task(tit, desc, p, da);
            d.getTask().add(t);
            t.salvaTaskSuDB(t,d.getEmail());
            Piattaforma.listaTask.add(t);
            return true;
        }else return false;
    }
    public static boolean DataCorretta(int g,int m, int a){
        Data d= new Data(g,m,a);
        return d.DatadiScadenzaCorretta();
    }

    public static boolean Cercatask(String tit){
        return Piattaforma.CercaTask(tit);
    }
    public static boolean CercataskClasse(ClasseVirtuale classe, String tit){
    	return classe.verificaTask(tit);
   
    }

    //public static void SpostaSoluzione(Task t, Soluzione s){

      //  t.SpostaSoluzioneCorretta(s);
   // }

    //public static ArrayList<Soluzione> ListaSoluzioni(Task t){
        //return t.getListaSoluzioni();
    //}

    public static void setConsegato(Soluzione s,Task t){
        s.setConsegntosuDB(s,t);
    }
    public static void setPunteggioDB(Soluzione s,Task t,int p){
        s.setPunteggioDB(s,t,p);
    }





}
