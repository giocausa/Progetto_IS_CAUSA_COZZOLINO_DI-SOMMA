package Control;
import Entity.*;


public class GestioneLogIn {

    public static String creaUtente(String nome, String cognome, String email, String password, boolean ruolo) {
        if (ruolo) {
            Studente s = new Studente(nome, cognome, email, password, ruolo);
            Piattaforma.addUtente(s);
            Piattaforma.addStudente(s);
            return "Studente aggiunto!";
        }else {
            Docente d = new Docente(nome, cognome, email, password, ruolo);
            Piattaforma.addUtente(d);
            Piattaforma.addDocente(d);
            return "Docente aggiunto!";
        }
    }

    public static void setUtenteLoggato(Utente u){
        Piattaforma.setUtenteLoggato(u);
    }

    public static boolean ControllaUtente(String email){
        if(Piattaforma.UtentePresente(email)) return true;
        else return false;
    }

    public static boolean ControlloAccesso(String email, String password){
        if (Piattaforma.ControlloAccesso(email,password)!=null){return true;}
        return false;
    }
    public static boolean ControlloTipo(String email, String password){
        Utente u=Piattaforma.ControlloAccesso(email,password);
        return u.getTipo();
    }

    public static Utente getUtente(String email, String password){
        return Piattaforma.ControlloAccesso(email,password);
    }

    public static Utente getUtenteLoggato(){
        return Piattaforma.getUtenteLoggato();
    }



}
