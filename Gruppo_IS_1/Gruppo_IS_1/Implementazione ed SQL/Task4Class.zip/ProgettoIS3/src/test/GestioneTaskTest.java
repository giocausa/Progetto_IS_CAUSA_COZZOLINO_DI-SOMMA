package test;

import Control.GestioneTask;
import Entity.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class GestioneTaskTest {

    private Docente docente;
    private Task task;
    private Soluzione soluzione;
    private Studente studente;
    private Piattaforma piattaforma;
    private ClasseVirtuale classeVirtuale;

    @Before
    public void setUp() {
        docente = new Docente("Mario", "Rossi", "mario@esempio.com", "password", false);
        studente = new Studente("Luca", "Verdi", "luca@studenti.it", "pass123", true);
        soluzione= new Soluzione("testo",studente);
        task=new Task("titolo","descrizione",30,new Data(10,7,2025));
        classeVirtuale=new ClasseVirtuale("4D","qwertyuiop");
        piattaforma=new Piattaforma();
        piattaforma.addTask(task);
        classeVirtuale.addTask(task);
        task.addSoluzioni(soluzione);

    }
    @Test
    public void testCercaTask() {
        GestioneTask.Cercatask("titolo");
        GestioneTask.Cercatask("123456789qwertyuiopasdfghjklzxcvbnm");
    }

    @Test
    public void testCereaTask(){
        assertTrue(GestioneTask.CreaTask(docente,"123456789","ciao",30,10,11,2025));
        assertFalse(GestioneTask.CreaTask(docente,"titolo","ciao",30,10,11,2025));
    }

    @Test
    public void testDataCorretta(){
        assertTrue(GestioneTask.DataCorretta(11,11,2030));
        assertFalse(GestioneTask.DataCorretta(11,11,2000));
    }

    @Test
    public void testCercataskClasse(){
        assertTrue(GestioneTask.CercataskClasse(classeVirtuale,"titolo"));
        assertFalse(GestioneTask.CercataskClasse(classeVirtuale,"123456789qwertyuiopasdfghjklzxcvbnm"));

    }

    @Test
    public void testsetConsegato(){
        GestioneTask.setConsegato(soluzione,task);
        assertTrue(soluzione.getConsegnato());
    }

    @After
    public void tearDown() throws Exception {
        piattaforma=null;
        assertTrue(piattaforma==null);
        docente=null;
        assertTrue(docente==null);
        studente=null;
        assertTrue(studente==null);
        classeVirtuale=null;
        assertTrue(classeVirtuale==null);
        task=null;
        assertTrue(task==null);
        soluzione=null;
        assertTrue(soluzione==null);
    }





}
