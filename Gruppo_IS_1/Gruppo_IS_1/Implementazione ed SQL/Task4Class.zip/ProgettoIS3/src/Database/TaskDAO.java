package Database;

import Entity.Task;
import Entity.Data;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TaskDAO {

    public static int salvaTask(Task t, String docenteEmail) {
        int ret = 0;

        String query = "INSERT INTO task (Titolo, descrizione, Data, punteggioMax, Docente_email) VALUES (\""
                + t.getTitolo() + "\", \""
                + t.getDescrizione() + "\", \""
                + t.getData().toString() + "\", "
                + t.getPunteggioMax() + ", \""
                + docenteEmail + "\")";

        System.out.println(query);

        try {
            ret = DBConnectionManager.updateQuery(query);
        } catch (SQLException e) {
            e.printStackTrace();
            ret = -1;
        }

        return ret;
    }

    public static boolean assegnaClasseATask(String titoloTask, String codiceClasse) {
        String query = "INSERT INTO task_classevirtuale (Task_Titolo, ClasseVirtuale_codiceunivoco) VALUES (\""
                + titoloTask + "\", \"" + codiceClasse + "\")";

        System.out.println(query);

        try {
            int result = DBConnectionManager.updateQuery(query);
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean assegnaClasseATask1(String titoloTask, String codiceClasse) {
        // ⚠️ Questa query non è coerente con lo schema SQL: la tabella `task` non ha `ClasseVirtuale_codiceunivoco`
        // La manteniamo per compatibilità, ma dovrebbe essere rimossa o corretta nel codice principale
        String query = "UPDATE task SET ClasseVirtuale_codiceunivoco = '" + codiceClasse + "' WHERE Titolo = '" + titoloTask + "'";
        System.out.println(query);

        try {
            int updated = DBConnectionManager.updateQuery(query);
            return updated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<Task> getTaskByClasseCodice(String codiceClasse) {
        List<Task> tasks = new ArrayList<>();

        String query = "SELECT t.Titolo, t.descrizione, t.Data, t.punteggioMax " +
                "FROM task t " +
                "JOIN task_classevirtuale a ON t.Titolo = a.Task_Titolo " +
                "WHERE a.ClasseVirtuale_codiceunivoco = \"" + codiceClasse + "\"";

        System.out.println(query);

        try {
            ResultSet rs = DBConnectionManager.selectQuery(query);
            while (rs.next()) {
                Date dataDB = rs.getDate("Data");
                Data data = new Data(dataDB.toLocalDate().getDayOfMonth(),
                        dataDB.toLocalDate().getMonthValue(),
                        dataDB.toLocalDate().getYear());

                Task t = new Task(
                        rs.getString("Titolo"),
                        rs.getString("descrizione"),
                        rs.getInt("punteggioMax"),
                        data
                );
                tasks.add(t);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return tasks;
    }

    public static List<Task> getTaskByDocenteEmail(String emailDocente) {
        List<Task> tasks = new ArrayList<>();

        String query = "SELECT Titolo, descrizione, Data, punteggioMax FROM task WHERE Docente_email = \"" + emailDocente + "\"";
        System.out.println(query);

        try {
            ResultSet rs = DBConnectionManager.selectQuery(query);
            while (rs.next()) {
                Date dataDB = rs.getDate("Data");
                Data data = new Data(dataDB.toLocalDate().getDayOfMonth(),
                        dataDB.toLocalDate().getMonthValue(),
                        dataDB.toLocalDate().getYear());

                Task t = new Task(
                        rs.getString("Titolo"),
                        rs.getString("descrizione"),
                        rs.getInt("punteggioMax"),
                        data
                );
                tasks.add(t);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return tasks;
    }

    public Task trovaPerTitolo(String titolo) {
        Task task = null;

        String query = "SELECT Titolo, descrizione, Data, punteggioMax FROM task WHERE Titolo = \"" + titolo + "\"";
        System.out.println(query);

        try {
            ResultSet rs = DBConnectionManager.selectQuery(query);
            if (rs.next()) {
                Date dataDB = rs.getDate("Data");
                Data data = new Data(dataDB.toLocalDate().getDayOfMonth(),
                        dataDB.toLocalDate().getMonthValue(),
                        dataDB.toLocalDate().getYear());

                task = new Task(
                        rs.getString("Titolo"),
                        rs.getString("descrizione"),
                        rs.getInt("punteggioMax"),
                        data
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return task;
    }

    public static List<Task> getTuttiITask() {
        List<Task> tasks = new ArrayList<>();

        String query = "SELECT Titolo, descrizione, Data, punteggioMax FROM task";
        System.out.println(query);

        try {
            ResultSet rs = DBConnectionManager.selectQuery(query);
            while (rs.next()) {
                Date dataDB = rs.getDate("Data");
                Data data = new Data(dataDB.toLocalDate().getDayOfMonth(),
                        dataDB.toLocalDate().getMonthValue(),
                        dataDB.toLocalDate().getYear());

                Task t = new Task(
                        rs.getString("Titolo"),
                        rs.getString("descrizione"),
                        rs.getInt("punteggioMax"),
                        data
                );
                tasks.add(t);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return tasks;
    }
}
