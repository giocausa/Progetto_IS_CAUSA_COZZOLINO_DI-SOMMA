package Database;

import Entity.ProfiloPersonale;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ProfiloPersonaleDAO {

    public int salvaProfilo(String emailStudente, ProfiloPersonale profilo) {
        int ret = 0;

        String query = "INSERT INTO profilopersonale (Studente_email, punteggioTotale, MediaVoti, TaskCompletati, contMedia) VALUES (\""
                + emailStudente + "\", "
                + profilo.getPunteggioTotale() + ", "
                + profilo.getMediaVoti() + ", "
                + profilo.getTaskCompletati() + ", "
                + profilo.getContMedia() + ")";

        try {
            ret = DBConnectionManager.updateQuery(query);
        } catch (SQLException e) {
            e.printStackTrace();
            ret = -1;
        }

        return ret;
    }

    public int aggiornaProfilo(String emailStudente, ProfiloPersonale profilo) {
        int ret = 0;

        String query = "UPDATE profilopersonale SET punteggioTotale = "
                + profilo.getPunteggioTotale() + ", MediaVoti = "
                + profilo.getMediaVoti() + ", TaskCompletati = "
                + profilo.getTaskCompletati() + ", contMedia = "
                + profilo.getContMedia() + " WHERE Studente_email = \"" + emailStudente + "\"";

        try {
            ret = DBConnectionManager.updateQuery(query);
        } catch (SQLException e) {
            e.printStackTrace();
            ret = -1;
        }

        return ret;
    }

    public static ProfiloPersonale caricaProfilo(String emailStudente) {
        ProfiloPersonale profilo = null;

        String query = "SELECT punteggioTotale, MediaVoti, TaskCompletati, contMedia FROM profilopersonale WHERE Studente_email = \"" + emailStudente + "\"";

        try {
            ResultSet rs = DBConnectionManager.selectQuery(query);
            if (rs.next()) {
                profilo = new ProfiloPersonale();
                profilo.setPunteggioTotaleDB(rs.getInt("punteggioTotale"));
                profilo.setMediaVotiDB(rs.getFloat("MediaVoti"));
                profilo.setTaskCompletatiDB(rs.getInt("TaskCompletati"));
                profilo.setContMediaDB(rs.getInt("contMedia"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return profilo;
    }

    public int eliminaProfiloPersonale(String email) {
        int ret = 0;

        String query = "DELETE FROM profilopersonale WHERE Studente_email = \"" + email + "\"";

        try {
            ret = DBConnectionManager.updateQuery(query);
        } catch (SQLException e) {
            e.printStackTrace();
            ret = -1;
        }

        return ret;
    }
}
