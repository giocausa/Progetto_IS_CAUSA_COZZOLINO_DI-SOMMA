package Database;

import Entity.ProfiloPersonale;
import Entity.Studente;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudenteDAO {

    public static int salvaInDB(Studente s) {
        int ret = 0;
        String query = "INSERT INTO studente (nome, cognome, email, password, ruolo, ClasseVirtuale_codiceunivoco) VALUES (?, ?, ?, ?, ?, NULL)";

        try (PreparedStatement stmt = DBConnectionManager.getConnection().prepareStatement(query)) {
            stmt.setString(1, s.getNome());
            stmt.setString(2, s.getCognome());
            stmt.setString(3, s.getEmail());
            stmt.setString(4, s.getPass());
            stmt.setInt(5, 1); // ruolo studente

            ret = stmt.executeUpdate();

            if (ret > 0) {
                String profiloQuery = "INSERT INTO profilopersonale (Studente_email, punteggioTotale, contMedia, MediaVoti, TaskCompletati) VALUES (?, 0, 0, 0.0, 0)";
                try (PreparedStatement profStmt = DBConnectionManager.getConnection().prepareStatement(profiloQuery)) {
                    profStmt.setString(1, s.getEmail());
                    profStmt.executeUpdate();
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            ret = -1;
        }

        return ret;
    }

    public static boolean assegnaClasseAStudente(String emailStudente, String codiceClasse) {
        String query = "UPDATE studente SET ClasseVirtuale_codiceunivoco = ? WHERE email = ?";

        try (PreparedStatement stmt = DBConnectionManager.getConnection().prepareStatement(query)) {
            stmt.setString(1, codiceClasse);
            stmt.setString(2, emailStudente);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Studente trovaPerEmail(String email) {
        Studente studente = null;
        String query = "SELECT nome, cognome, email, password FROM studente WHERE email = ?";

        try (PreparedStatement stmt = DBConnectionManager.getConnection().prepareStatement(query)) {
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                ProfiloPersonale profilo = ProfiloPersonaleDAO.caricaProfilo(email);
                studente = new Studente(
                        rs.getString("nome"),
                        rs.getString("cognome"),
                        rs.getString("email"),
                        rs.getString("password"),
                        true,
                        profilo
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return studente;
    }

    public static List<Studente> getTuttiGliStudenti() {
        List<Studente> studenti = new ArrayList<>();
        String query = "SELECT nome, cognome, email, password FROM studente";

        try (PreparedStatement stmt = DBConnectionManager.getConnection().prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String email = rs.getString("email");
                ProfiloPersonale profilo = ProfiloPersonaleDAO.caricaProfilo(email);

                Studente s = new Studente(
                        rs.getString("nome"),
                        rs.getString("cognome"),
                        email,
                        rs.getString("password"),
                        true,
                        profilo
                );
                studenti.add(s);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return studenti;
    }

    public static List<Studente> getStudentiPerClasse(String codiceClasse) {
        List<Studente> studenti = new ArrayList<>();
        String query = "SELECT nome, cognome, email, password FROM studente WHERE ClasseVirtuale_codiceunivoco = ?";

        try (PreparedStatement stmt = DBConnectionManager.getConnection().prepareStatement(query)) {
            stmt.setString(1, codiceClasse);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String email = rs.getString("email");
                ProfiloPersonale profilo = ProfiloPersonaleDAO.caricaProfilo(email);

                Studente s = new Studente(
                        rs.getString("nome"),
                        rs.getString("cognome"),
                        email,
                        rs.getString("password"),
                        true,
                        profilo
                );
                studenti.add(s);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return studenti;
    }

    public int eliminaStudente(String email) {
        int ret = 0;
        String query = "DELETE FROM studente WHERE email = ?";

        try (PreparedStatement stmt = DBConnectionManager.getConnection().prepareStatement(query)) {
            stmt.setString(1, email);
            ret = stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            ret = -1;
        }

        return ret;
    }
}