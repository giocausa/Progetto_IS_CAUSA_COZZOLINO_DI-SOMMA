package Entity;

import java.util.ArrayList;
import java.util.List;

import Database.ProfiloPersonaleDAO;
import Database.SoluzioneDAO;
import Database.TaskDAO;

public class Task {
    private String titolo;
    private String descrizione;
    private Data data;
    private int punteggioMax;
    private ArrayList<Soluzione> listaSoluzioni;
    private ArrayList<Soluzione> listaSoluzioniCorrette;
    private transient TaskDAO taskDAO=new TaskDAO();

    
    public Task (String t, String d, int p, Data da) {
    	this.titolo=t;
    	this.descrizione=d;
        this.data=da;
    	this.punteggioMax=p;
        this.listaSoluzioni = (ArrayList<Soluzione>) SoluzioneDAO.getSoluzioniNonConsegnatePerTask(titolo);
        this.listaSoluzioniCorrette = (ArrayList<Soluzione>) SoluzioneDAO.getSoluzioniConsegnatePerTask(titolo);


    }


    public String getTitolo() {
    	return this.titolo;
    }
    public String getDescrizione() {return this.descrizione;}
    public Data getData() {return this.data;}
    public int getPunteggioMax() {return this.punteggioMax;}
    public ArrayList<Soluzione> getListaSoluzioni() {return (ArrayList<Soluzione>) SoluzioneDAO.getSoluzioniNonConsegnatePerTask(this.titolo);}
    public TaskDAO getTaskDAO() {return this.taskDAO;}
    public void addSoluzioni(Soluzione s) {
        this.listaSoluzioni.add(s);

        Studente studente = s.getStudente();
        ProfiloPersonale profilo = studente.getProfilo();

        if (profilo == null) {
            profilo = new ProfiloPersonale();
            new ProfiloPersonaleDAO().salvaProfilo(studente.getEmail(), profilo);
            studente.setProfilo(profilo);
        }

        profilo.setTaskCompletati(studente.getEmail());
        s.setConsegnato(true);
    }




    public void SpostaSoluzioneCorretta(Soluzione s) {
        s.setConsegnato(true);
    }

    @Override
    public String toString() {
        return titolo;
    }

    public int salvaTaskSuDB(Task t, String docenteEmail) {
        return this.taskDAO.salvaTask(t, docenteEmail);
    }

    public boolean aggiungiSoluzione(String t,Soluzione s){
        if (!SoluzioneDAO.studenteHaGiaConsegnato(s.getStudente().getEmail(),t)) {
            return true;
        }else return false;

    }

    public void Aggiornalista(){
        this.listaSoluzioni = (ArrayList<Soluzione>) SoluzioneDAO.getSoluzioniNonConsegnatePerTask(this.titolo);
        this.listaSoluzioniCorrette = (ArrayList<Soluzione>) SoluzioneDAO.getSoluzioniConsegnatePerTask(this.titolo);
    }

    //public Task trovaTaskPerTitolo(String titolo) {
    //    return taskDAO.trovaPerTitolo(titolo);
    //}

    //public ArrayList<Soluzione> getListaSoluzioniConsegnatePerTask(){
        //reutrn this.listaSoluzioni;
    //}


}


