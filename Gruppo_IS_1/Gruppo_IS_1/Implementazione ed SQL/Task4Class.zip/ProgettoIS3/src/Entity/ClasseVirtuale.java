package Entity;


import java.util.ArrayList;
import Database.ClasseVirtualeDAO;
import Database.StudenteDAO;
import Database.TaskDAO;

public class ClasseVirtuale {
    private String nome;
    private String codUnivoco;
    private  ArrayList<Studente> studenti;
    private  ArrayList<Task> task;
    private Classifica classifica;
    private transient ClasseVirtualeDAO dao = new ClasseVirtualeDAO();

    public ClasseVirtuale (String n, String c) {
        this.nome = n;
        this.codUnivoco = c;
        this.studenti= (ArrayList<Studente>)StudenteDAO.getStudentiPerClasse(c);
        this.task= (ArrayList<Task>)TaskDAO.getTaskByClasseCodice(c);
        this.classifica=new Classifica(studenti);
    }


    public ArrayList getStudenti(){
        return this.studenti;
    }
    public ArrayList getTask(){
        return this.task;
    }
    public String getCodUnivoco(){
        return this.codUnivoco;
    }
    public String getNome(){return this.nome;}
    public Classifica getClassifica(){return this.classifica;}

    public void addStudente(Studente s){
        StudenteDAO.assegnaClasseAStudente(s.getEmail(),this.codUnivoco);
        this.studenti.add(s);
    }

    public void addTask(Task t){
        TaskDAO.assegnaClasseATask(t.getTitolo(),this.codUnivoco);
        this.task.add(t);
    }

    public boolean verificaStudente(String email){
        for (Studente s : studenti) {
            if (s.getEmail().equals(email)) {
                return true;
            }
        } return false;
    }

    public boolean verificaTask(String tit){
        for (Task t : task) {
            if (t.getTitolo().equals(tit)) {
                return true;
            }
        } return false;
    }


    public int salvaSuDatabase(Docente d) {
        return dao.salvaClasse(this, d);
    }

    @Override
    public String toString() {
        return nome;

    }
}
