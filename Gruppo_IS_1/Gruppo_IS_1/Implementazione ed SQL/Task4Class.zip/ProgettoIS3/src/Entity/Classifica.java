package Entity;

import java.util.ArrayList;

import static Entity.Studente.comparatorePerPunteggioTotale;
import static Entity.Studente.comparatorePerTaskCompletati;


public class Classifica {
    // private boolean tipo;
    private ArrayList<Studente>  studenti;

    public Classifica(ArrayList<Studente>  s){
        this.studenti=s;
        //PUNTANO ALLA STESSA CELLA DI MEMORIA
    }

    //l'aggiornamento della classifica viene fatta prima di ogni generazione, in modo tale che venga ordinata solo quando necessario
    public ArrayList<Studente>  GeneraClassificaPunteggioTotale(){
        this.studenti.sort(comparatorePerPunteggioTotale);
        return this.studenti;
    }

    public ArrayList<Studente>  GeneraClassificaNumTask(){
        this.studenti.sort(comparatorePerTaskCompletati);
        return this.studenti;
    }

}
