package Entity;
import java.time.LocalDate;

public class Data {
    private int giorno;
    private int mese;
    private int anno;

    public Data(int g, int m, int a){
        this.giorno=g;
        this.mese=m;
        this.anno=a;
    }
    public int getGiorno() {
        return this.giorno;
    }
    public int getMese() {
        return this.mese;
    }
    public int getAnno() {
        return this.anno;
    }
    public Data(){
        this.giorno=0;
        this.mese=0;
        this.anno=0;
    }
    public void setLocalDate(){
        LocalDate oggi = LocalDate.now();
        this.giorno=oggi.getDayOfMonth();
        this.mese=oggi.getMonthValue();
        this.anno=oggi.getYear();
    }
    public boolean DatadiScadenzaCorretta() {
        LocalDate oggi = LocalDate.now();
        LocalDate dataInserita = LocalDate.of(this.anno, this.mese, this.giorno);
        return dataInserita.isAfter(oggi);

    }

    @Override
    public String toString() {
        return anno+"-"+mese+"-"+giorno;
    }
}
