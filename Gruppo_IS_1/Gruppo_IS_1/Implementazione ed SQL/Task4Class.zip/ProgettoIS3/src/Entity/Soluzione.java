package Entity;
import Database.SoluzioneDAO;

public class Soluzione {
    private String testo;
    private int punteggio;
    private Data data;
    private Studente studente;
    private boolean consegnato;
    private transient SoluzioneDAO soluzioneDAO=new SoluzioneDAO();



    public Soluzione(String  t, Studente s){
        this.testo=t;
        this.punteggio=0;
        this.data=new Data();
        this.data.setLocalDate();
        this.studente=s;
        this.consegnato=false;
    }

    public Soluzione(String testo, int punteggio, Data data, Studente studente, boolean consegnato) {
        this.testo = testo;
        this.punteggio = punteggio;
        this.data = data;
        this.studente = studente;
        this.consegnato = consegnato;
    }



    public Studente getStudente(){
        return this.studente;
    }

    public String getTesto(){
        return this.testo;
    }

    public Data getData(){
        return data;
    }

    public void setPunteggio(String email,int p){
        this.punteggio=p;
        this.studente.getProfilo().setPunteggioTotale(email,p);
        this.consegnato=true;
    }
    public void setConsegntosuDB(Soluzione s, Task t){
        SoluzioneDAO.setSoluzioneNonConsegnata(s.getStudente().getEmail(), t.getTitolo());
    }
    public void setPunteggioDB(Soluzione s, Task t, int p){
        SoluzioneDAO.updatePunteggioSoluzione(s.getStudente().getEmail(), t.getTitolo(), p);
    }

    @Override
    public String toString() {
        return this.studente.toString();
    }

    public int salvaSoluzioneSuDB(Soluzione s,String taskTitolo) {
        return soluzioneDAO.salvaSoluzione(s, taskTitolo);
    }

    public int getPunteggio() {
        return this.punteggio;
    }


    public boolean getConsegnato(){
        return this.consegnato;
    }

    public void setConsegnato(boolean c){
        this.consegnato=c;
    }


    public void setData(Data d) {
        this.data=d;
    }
}

