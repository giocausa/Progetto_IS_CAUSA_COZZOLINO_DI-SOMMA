package Entity;

import java.util.Objects;

public class Utente {
    private String nome;
    private String cognome;
    private String email;
    private String password;
    private boolean rule;

    public Utente(String n, String c, String e, String p, boolean r){
        this.nome=n;
        this.cognome=c;
        this.email=e;
        this.password=p;
        this.rule=r;
    }

    public String getEmail(){
        return this.email;
    }
    public String getPass(){return this.password; }
    public boolean getTipo(){return this.rule; }
    public String getNome(){return this.nome; }
    public String getCognome(){return this.cognome; }


    @Override
    public String toString() {
        return nome +" "+ cognome;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Utente utente = (Utente) o;
        return Objects.equals(email, utente.email);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(email);
    }
}
