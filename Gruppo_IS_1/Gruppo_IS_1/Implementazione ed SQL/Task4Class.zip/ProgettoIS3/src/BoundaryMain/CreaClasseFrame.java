package BoundaryMain;

import Control.GestioneClassiVirtuali;
import Control.GestioneDocenti;
import Control.GestioneLogIn;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class CreaClasseFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField NomeText;
	private JTextField CodiceText;
	private JTextField OutPutText;
	private JTextField OutputTextNome;
	private JTextField OutPutTextCod;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreaClasseFrame frame = new CreaClasseFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CreaClasseFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Crea Classe Virtuale");
		lblNewLabel.setFont(new Font("Source Sans Pro Semibold", Font.BOLD, 31));
		lblNewLabel.setBounds(10, 10, 271, 40);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Inserisci nome della classe:");
		lblNewLabel_1.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(10, 60, 171, 24);
		contentPane.add(lblNewLabel_1);
		
		NomeText = new JTextField();
		NomeText.setBounds(191, 62, 176, 24);
		contentPane.add(NomeText);
		NomeText.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Inserisci codice della classe:");
		lblNewLabel_1_1.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_1_1.setBounds(10, 94, 171, 24);
		contentPane.add(lblNewLabel_1_1);
		
		CodiceText = new JTextField();
		CodiceText.setColumns(10);
		CodiceText.setBounds(191, 96, 176, 24);
		contentPane.add(CodiceText);
		
		OutPutText = new JTextField();
		OutPutText.setEditable(false);
		OutPutText.setBounds(191, 130, 176, 40);
		contentPane.add(OutPutText);
		OutPutText.setColumns(10);
		
		JButton BotConferma = new JButton("Conferma");
		BotConferma.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(GestioneClassiVirtuali.creaClasseVirtuale(GestioneDocenti.TrovaDocente(GestioneLogIn.getUtenteLoggato().getEmail()), NomeText.getText(),CodiceText.getText())){
					OutPutText.setText("Classe Creata");
					OutputTextNome.setText(NomeText.getText());
					OutPutTextCod.setText(CodiceText.getText());
				}else {
					OutPutText.setText("Codice già esistente");
					OutputTextNome.setText("");
					OutPutTextCod.setText("");
				}
			}
		});
		BotConferma.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotConferma.setBounds(10, 128, 171, 42);
		contentPane.add(BotConferma);
		
		JLabel lblNewLabel_2 = new JLabel("Classe creata:");
		lblNewLabel_2.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(10, 180, 83, 24);
		contentPane.add(lblNewLabel_2);
		
		OutputTextNome = new JTextField();
		OutputTextNome.setEditable(false);
		OutputTextNome.setBounds(103, 182, 176, 24);
		contentPane.add(OutputTextNome);
		OutputTextNome.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Codice:");
		lblNewLabel_3.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(10, 214, 83, 24);
		contentPane.add(lblNewLabel_3);
		
		OutPutTextCod = new JTextField();
		OutPutTextCod.setEditable(false);
		OutPutTextCod.setColumns(10);
		OutPutTextCod.setBounds(103, 216, 176, 24);
		contentPane.add(OutPutTextCod);
		
		JButton btnNewButton_1 = new JButton("Home");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DocentiFrame df= new DocentiFrame();
				df.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		btnNewButton_1.setBounds(289, 180, 78, 58);
		contentPane.add(btnNewButton_1);
	}
}
