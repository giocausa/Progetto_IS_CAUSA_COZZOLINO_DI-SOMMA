package BoundaryMain;

import Control.GestioneLogIn;
import Control.GestioneSoluzioni;
import Control.GestioneStudenti;
import Entity.Task;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class CaricaSoluzioneFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField OutPut;
	private JTextField DataTaskOutPut;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					//CaricaSoluzioneFrame frame = new CaricaSoluzioneFrame();
					//frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CaricaSoluzioneFrame(Task t) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JTextArea SoluzioneText = new JTextArea();
		SoluzioneText.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		SoluzioneText.setBounds(10, 36, 191, 155);
		contentPane.add(SoluzioneText);
		
		JButton btnNewButton = new JButton("Invia Soluzione");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(GestioneSoluzioni.aggiungiSoluzione(t,GestioneSoluzioni.CreaSoluzione(GestioneStudenti.TrovaStudente(GestioneLogIn.getUtenteLoggato().getEmail()),SoluzioneText.getText()))){
					OutPut.setText("Soluzione Caricata");
				}else OutPut.setText("Hai gia caricato una soluzione");

			}
		});
		btnNewButton.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		btnNewButton.setBounds(10, 201, 191, 52);
		contentPane.add(btnNewButton);
		
		OutPut = new JTextField();
		OutPut.setEditable(false);
		OutPut.setBounds(211, 201, 225, 52);
		contentPane.add(OutPut);
		OutPut.setColumns(10);

		
		JLabel lblNewLabel = new JLabel("Inserisci Soluzione:");
		lblNewLabel.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel.setBounds(10, 10, 191, 16);
		contentPane.add(lblNewLabel);
		
		
		
		
		JScrollPane scrollPane_1 = new JScrollPane(SoluzioneText);
		scrollPane_1.setBounds(10, 36, 191, 155);
		contentPane.add(scrollPane_1);
		
		JLabel lblNewLabel_1 = new JLabel("Descrizione Task:");
		lblNewLabel_1.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(239, 40, 114, 16);
		contentPane.add(lblNewLabel_1);
		
		DataTaskOutPut = new JTextField();
		DataTaskOutPut.setEditable(false);
		DataTaskOutPut.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		DataTaskOutPut.setBounds(239, 163, 197, 28);
		contentPane.add(DataTaskOutPut);
		DataTaskOutPut.setColumns(10);
		DataTaskOutPut.setText("Data di scadenza: "+t.getData().toString());
		
		JTextArea DescTaskOutPut = new JTextArea();
		DescTaskOutPut.setBounds(239, 66, 197, 92);
		contentPane.add(DescTaskOutPut);
		DescTaskOutPut.setText(t.getDescrizione());
		
		JButton BotHome = new JButton("Home");
		BotHome.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				StudenteFrame sf =new StudenteFrame();
				sf.setVisible(true);
			}
		});
		BotHome.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotHome.setBounds(351, 9, 85, 47);
		contentPane.add(BotHome);
		
		JScrollPane scrollPane = new JScrollPane(DescTaskOutPut);
		scrollPane.setBounds(239, 66, 197, 92);
		contentPane.add(scrollPane);
	}
}
