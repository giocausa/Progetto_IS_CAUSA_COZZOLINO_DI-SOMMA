package BoundaryMain;

import Control.GestioneClassiVirtuali;
import Control.GestioneLogIn;
import Entity.Studente;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JToggleButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class ClassificaFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable classificaMedia;
	private JTable classificaNumTask;
	private final JPanel classMedia = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClassificaFrame frame = new ClassificaFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ClassificaFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton BotHome = new JButton("Home");
		BotHome.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				StudenteFrame sf = new StudenteFrame();
				sf.setVisible(true);
			}
		});
		BotHome.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotHome.setBounds(329, 10, 107, 35);
		contentPane.add(BotHome);
		classMedia.setBounds(10, 55, 416, 86);
		contentPane.add(classMedia);
		classMedia.setLayout(null);
		classMedia.setVisible(false);
		
		classificaMedia = new JTable();
		classificaMedia.setRowSelectionAllowed(false);
		classificaMedia.setBounds(0, 0, 416, 86);
		classMedia.add(classificaMedia);
		classificaMedia.setBorder(new LineBorder(new Color(0, 0, 0)));
		classificaMedia.setFont(new Font("Tahoma", Font.PLAIN, 10));
		classificaMedia.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
			},
			new String[] {
				"Posizione", "Studente", "Punteggio"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				true, true, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		
		JPanel classNumTask = new JPanel();
		classNumTask.setBounds(10, 183, 426, 80);
		contentPane.add(classNumTask);
		classNumTask.setLayout(null);
		classNumTask.setVisible(false);
		
		classificaNumTask = new JTable();
		classificaNumTask.setRowSelectionAllowed(false);
		classificaNumTask.setBounds(0, 0, 416, 80);
		classNumTask.add(classificaNumTask);
		classificaNumTask.setBorder(new LineBorder(new Color(0, 0, 0)));
		classificaNumTask.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
			},
			new String[] {
				"Posizione", "Studente", "Punteggio"
			}
		));
		classificaNumTask.setFont(new Font("Tahoma", Font.PLAIN, 10));
		
		JToggleButton BotPuntTot = new JToggleButton("Genera Classifica PunteggioTotale");
		BotPuntTot.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				classMedia.setVisible(BotPuntTot.isSelected());
				ArrayList<Studente> studenti=GestioneClassiVirtuali.RestituisciClasseStudente(GestioneLogIn.getUtenteLoggato().getEmail()).getClassifica().GeneraClassificaPunteggioTotale();
				DefaultTableModel model = (DefaultTableModel) classificaMedia.getModel();
				model.setRowCount(0);
				int posizione = 1;
				for (Studente s : studenti) {
					model.addRow(new Object[]{posizione++, s.getNome(), s.getProfilo().getPunteggioTotale()});
				}
				
			}
		});
		BotPuntTot.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotPuntTot.setBounds(10, 18, 247, 21);
		contentPane.add(BotPuntTot);


	
		
		JToggleButton BotNumTask = new JToggleButton("Genera Classifica NumTask");
		BotNumTask.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				classNumTask.setVisible(BotNumTask.isSelected());
				ArrayList<Studente> studenti=GestioneClassiVirtuali.RestituisciClasseStudente(GestioneLogIn.getUtenteLoggato().getEmail()).getClassifica().GeneraClassificaNumTask();
				DefaultTableModel model1 = (DefaultTableModel) classificaNumTask.getModel();
				model1.setRowCount(0);
				int posizione = 1;
				for (Studente s : studenti) {
					model1.addRow(new Object[]{posizione++, s.getNome(), s.getProfilo().getTaskCompletati()});
				}

			}
		});
		BotNumTask.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotNumTask.setBounds(10, 151, 247, 21);
		contentPane.add(BotNumTask);
	}
}
