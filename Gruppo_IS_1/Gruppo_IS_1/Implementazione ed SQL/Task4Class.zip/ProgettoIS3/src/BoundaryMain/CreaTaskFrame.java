package BoundaryMain;

import Control.GestioneDocenti;
import Control.GestioneLogIn;
import Control.GestioneTask;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;

public class CreaTaskFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField TitoloText;
	private JTextField OutPut;
	private JTextField PunteggioText;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CreaTaskFrame frame = new CreaTaskFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CreaTaskFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Crea Task");
		lblNewLabel.setFont(new Font("Source Sans Pro Semibold", Font.BOLD, 31));
		lblNewLabel.setBounds(10, 10, 139, 44);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Inserisci titolo:");
		lblNewLabel_1.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(10, 78, 97, 25);
		contentPane.add(lblNewLabel_1);
		
		TitoloText = new JTextField();
		TitoloText.setBounds(117, 79, 125, 25);
		contentPane.add(TitoloText);
		TitoloText.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Inserisci descrizione:");
		lblNewLabel_2.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(10, 113, 125, 25);
		contentPane.add(lblNewLabel_2);
		
		JTextArea DescText = new JTextArea();
		DescText.setBounds(163, 114, 263, 85);
		contentPane.add(DescText);

		JComboBox AnnoB = new JComboBox();
		//AnnoB.setSelectedIndex(1);
		AnnoB.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		AnnoB.setBounds(359, 43, 67, 25);
		contentPane.add(AnnoB);
		for (int i = 2025; i <= 2050; i++) {
			AnnoB.addItem(i);
		}
		AnnoB.setSelectedIndex(0);

		JComboBox MeseB = new JComboBox();
		//MeseB.setSelectedIndex(1);
		MeseB.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		MeseB.setBounds(305, 43, 44, 25);
		contentPane.add(MeseB);
		for (int i = 1; i <= 12; i++) {
			MeseB.addItem(i);
		}
		MeseB.setSelectedIndex(0);

		JComboBox GiornoB = new JComboBox();
		//GiornoB.setSelectedIndex(1);
		GiornoB.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		GiornoB.setBounds(251, 43, 44, 25);
		contentPane.add(GiornoB);
		for (int i = 1; i <= 31; i++) {
			GiornoB.addItem(i);
		}
		GiornoB.setSelectedIndex(0);
		
		JButton BotConferma = new JButton("Conferma");
		BotConferma.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				if (GestioneTask.DataCorretta( Integer.parseInt(GiornoB.getSelectedItem().toString()),Integer.parseInt(MeseB.getSelectedItem().toString()),Integer.parseInt(AnnoB.getSelectedItem().toString()))){
					if( !PunteggioText.getText().trim().isEmpty()) {
						if (GestioneTask.CreaTask((GestioneDocenti.TrovaDocente(GestioneLogIn.getUtenteLoggato().getEmail())),TitoloText.getText(),DescText.getText(),Integer.parseInt(PunteggioText.getText()), Integer.parseInt(GiornoB.getSelectedItem().toString()),Integer.parseInt(MeseB.getSelectedItem().toString()),Integer.parseInt(AnnoB.getSelectedItem().toString()))){
							OutPut.setText("Task Creato");
						}else {
							OutPut.setText("Titolo già esistente");
						}
					}else OutPut.setText("Punteggio non inserito");
				}else OutPut.setText("Data inserita passata");
			}
		});
		BotConferma.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotConferma.setBounds(10, 148, 125, 44);
		contentPane.add(BotConferma);
		
		OutPut = new JTextField();
		OutPut.setEditable(false);
		OutPut.setBounds(172, 209, 254, 44);
		contentPane.add(OutPut);
		OutPut.setColumns(10);
		
		JButton BotHome = new JButton("Home");
		BotHome.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DocentiFrame df =new DocentiFrame();
				df.setVisible(true);
			}
		});
		BotHome.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotHome.setBounds(10, 207, 125, 44);
		contentPane.add(BotHome);
		
		JLabel lblNewLabel_1_1 = new JLabel("MAX Punteggio:");
		lblNewLabel_1_1.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_1_1.setBounds(252, 78, 97, 25);
		contentPane.add(lblNewLabel_1_1);
		
		PunteggioText = new JTextField();
		PunteggioText.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
			    if (!Character.isDigit(c)) {
			        e.consume(); 
			        OutPut.setText("Devi inserire un numero");
			    	}	else OutPut.setText("");	
			    }
		});
		PunteggioText.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		PunteggioText.setBounds(359, 78, 67, 25);
		contentPane.add(PunteggioText);
		PunteggioText.setColumns(10);
		

		
		JLabel lblNewLabel_3 = new JLabel("Data di scadenza:");
		lblNewLabel_3.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(141, 51, 112, 18);
		contentPane.add(lblNewLabel_3);
		
		JScrollPane DescScroll = new JScrollPane(DescText);
		DescScroll.setBounds(163, 114, 263, 85);
		contentPane.add(DescScroll);
	}
}
