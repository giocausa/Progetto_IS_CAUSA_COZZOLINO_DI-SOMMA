package BoundaryMain;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import Control.GestioneLogIn;


public class RegistratiFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField NomeText;
	private JTextField CognomeText;
	private JTextField EmailText;
	private JTextField PassText;
	private JTextField ConfPassText;
	private JTextField Output;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegistratiFrame frame = new RegistratiFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegistratiFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Registrati");
		lblNewLabel.setFont(new Font("Source Sans Pro Semibold", Font.BOLD, 31));
		lblNewLabel.setBounds(154, 10, 147, 40);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Nome:");
		lblNewLabel_1.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(10, 105, 45, 13);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Cognome:");
		lblNewLabel_2.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(10, 123, 68, 18);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("E-mail:");
		lblNewLabel_3.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(10, 151, 45, 13);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Password:");
		lblNewLabel_4.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_4.setBounds(10, 174, 68, 13);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Conferma Password:");
		lblNewLabel_5.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_5.setBounds(10, 197, 125, 13);
		contentPane.add(lblNewLabel_5);
		
		JRadioButton BotStudente = new JRadioButton("Studente");
		BotStudente.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotStudente.setBounds(6, 78, 103, 21);
		contentPane.add(BotStudente);
		
		JRadioButton BotDocente = new JRadioButton("Docente");
		BotDocente.setSelected(true);
		BotDocente.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotDocente.setBounds(128, 78, 103, 21);
		contentPane.add(BotDocente);
		
		ButtonGroup gruppo = new ButtonGroup();
		gruppo.add(BotStudente);
		gruppo.add(BotDocente);
		
		NomeText = new JTextField();
		NomeText.setBounds(167, 103, 96, 19);
		contentPane.add(NomeText);
		NomeText.setColumns(10);
		
		CognomeText = new JTextField();
		CognomeText.setBounds(167, 124, 96, 19);
		contentPane.add(CognomeText);
		CognomeText.setColumns(10);
		
		EmailText = new JTextField();
		EmailText.setBounds(167, 149, 96, 19);
		contentPane.add(EmailText);
		EmailText.setColumns(10);
		
		PassText = new JTextField();
		PassText.setBounds(167, 172, 96, 19);
		contentPane.add(PassText);
		PassText.setColumns(10);
		
		ConfPassText = new JTextField();
		ConfPassText.setBounds(167, 195, 96, 19);
		contentPane.add(ConfPassText);
		ConfPassText.setColumns(10);
		
		Output = new JTextField();
		Output.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		Output.setEditable(false);
		Output.setBounds(273, 151, 163, 103);
		contentPane.add(Output);
		Output.setColumns(10);
		
		JButton BotConferma = new JButton("Conferma");
		BotConferma.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				  String pass1 = PassText.getText();
			      String pass2 = ConfPassText.getText();
				  String email = EmailText.getText();
				  String nome = NomeText.getText();
				  String cognome = CognomeText.getText();
				  boolean ruolo= BotStudente.isSelected();// se è vero significa che è stato selezionato lo studente
			        if (!pass1.equals(pass2)) {
			            Output.setText("Password diverse");
			        } else if (!GestioneLogIn.ControllaUtente(email)){
						Output.setText(GestioneLogIn.creaUtente(nome, cognome, email, pass1, ruolo));
			        }else Output.setText("Utente con questa email già presente");
			    
			}
		});
		BotConferma.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotConferma.setBounds(167, 224, 96, 29);
		contentPane.add(BotConferma);
		
		JButton BotAccedi = new JButton("Accedi");
		BotAccedi.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				AccediFrame AccediFrame = new AccediFrame();
				AccediFrame.setVisible(true);
			}
		});
		BotAccedi.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotAccedi.setBounds(273, 91, 163, 50);
		contentPane.add(BotAccedi);
		
		
	}
}
