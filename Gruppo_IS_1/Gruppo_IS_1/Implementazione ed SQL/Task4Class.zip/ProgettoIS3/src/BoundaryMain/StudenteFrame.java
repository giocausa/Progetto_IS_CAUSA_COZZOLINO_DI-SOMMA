package BoundaryMain;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JToggleButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;

import Control.GestioneClassiVirtuali;
import Control.GestioneLogIn;
import Control.GestioneStudenti;
import Entity.Task;

import javax.swing.UIManager;
import javax.swing.JList;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class StudenteFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField MediaVotiText;
	private JTextField PuntTotText;
	private JTextField TaskCompleText;
	private JTextField OutPut;
	private JTextField NomUtenteOutPut;
	private JTextField ClasseOutPut;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudenteFrame frame = new StudenteFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StudenteFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel ProfPersonalePanel = new JPanel();
		ProfPersonalePanel.setBounds(247, 132, 163, 70);
		contentPane.add(ProfPersonalePanel);
		ProfPersonalePanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Media Voti:");
		lblNewLabel.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel.setBounds(0, 0, 66, 25);
		ProfPersonalePanel.add(lblNewLabel);
		
		JLabel lblTaskCompletati = new JLabel("Task Completati:");
		lblTaskCompletati.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblTaskCompletati.setBounds(0, 45, 109, 25);
		ProfPersonalePanel.add(lblTaskCompletati);
		
		JLabel lblNewLabel_1_1 = new JLabel("Punteggio Totale:");
		lblNewLabel_1_1.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_1_1.setBounds(0, 22, 109, 25);
		ProfPersonalePanel.add(lblNewLabel_1_1);
		
		MediaVotiText = new JTextField();
		MediaVotiText.setEditable(false);
		MediaVotiText.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		MediaVotiText.setBounds(110, 2, 51, 20);
		ProfPersonalePanel.add(MediaVotiText);
		MediaVotiText.setColumns(10);
		
		PuntTotText = new JTextField();
		PuntTotText.setEditable(false);
		PuntTotText.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		PuntTotText.setColumns(10);
		PuntTotText.setBounds(110, 24, 51, 20);
		ProfPersonalePanel.add(PuntTotText);
		
		TaskCompleText = new JTextField();
		TaskCompleText.setEditable(false);
		TaskCompleText.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		TaskCompleText.setColumns(10);
		TaskCompleText.setBounds(110, 47, 51, 20);
		ProfPersonalePanel.add(TaskCompleText);
		ProfPersonalePanel.setVisible(false);
		
		
		JToggleButton BotProfPersonale = new JToggleButton("Profilo Personale");
		BotProfPersonale.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				boolean selected = BotProfPersonale.isSelected();
				ProfPersonalePanel.setVisible(selected);
				float media =GestioneStudenti.TrovaStudente(GestioneLogIn.getUtenteLoggato().getEmail()).getProfilo().getMediaVoti();
				int punteggioTot =GestioneStudenti.TrovaStudente(GestioneLogIn.getUtenteLoggato().getEmail()).getProfilo().getPunteggioTotale();
				int taskCompletati =GestioneStudenti.TrovaStudente(GestioneLogIn.getUtenteLoggato().getEmail()).getProfilo().getTaskCompletati();
				MediaVotiText.setText(String.valueOf(media));
				TaskCompleText.setText(String.valueOf(taskCompletati));
				PuntTotText.setText(String.valueOf(punteggioTot));
			}
		});


		BotProfPersonale.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotProfPersonale.setBounds(227, 88, 199, 34);
		contentPane.add(BotProfPersonale);
		
		OutPut = new JTextField();
		OutPut.setEditable(false);
		OutPut.setBounds(10, 212, 416, 51);
		contentPane.add(OutPut);
		OutPut.setColumns(10);
		
		JButton btnNewButton = new JButton("x");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MainFrame mf = new MainFrame();
				mf.setVisible(true);
			}
		});

		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 10));
		btnNewButton.setBackground(UIManager.getColor("Button.background"));
		btnNewButton.setBounds(387, 10, 39, 30);
		contentPane.add(btnNewButton);

		
		NomUtenteOutPut = new JTextField();
		NomUtenteOutPut.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		NomUtenteOutPut.setEditable(false);
		NomUtenteOutPut.setBounds(10, 16, 194, 24);
		contentPane.add(NomUtenteOutPut);
		NomUtenteOutPut.setColumns(10);
		NomUtenteOutPut.setText(GestioneLogIn.getUtenteLoggato().toString());
		
		JButton BotAggStudenteStudente = new JButton("Iscriviti ad una Classe");
		BotAggStudenteStudente.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//GestioneStudenti.TrovaStudente(GestioneLogIn.getUtenteLoggato().getEmail())
				if(!GestioneClassiVirtuali.verificaIscrizioneStudente(GestioneLogIn.getUtenteLoggato().getEmail())){
					AggStudenteStudente ass = new AggStudenteStudente();
					ass.setVisible(true);
				}else OutPut.setText("Sei già iscritto ad una Classe");
			}
		});
		
		BotAggStudenteStudente.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotAggStudenteStudente.setBounds(208, 14, 176, 21);
		contentPane.add(BotAggStudenteStudente);
		
		ClasseOutPut = new JTextField();
		ClasseOutPut.setEditable(false);
		ClasseOutPut.setFont(new Font("Source Serif Pro", Font.PLAIN, 14));
		ClasseOutPut.setBounds(227, 45, 183, 33);
		contentPane.add(ClasseOutPut);
		ClasseOutPut.setColumns(10);
		try {
			ClasseOutPut.setText("Classe: "+GestioneClassiVirtuali.RestituisciClasseStudente(GestioneLogIn.getUtenteLoggato().getEmail()).toString());
		}catch (NullPointerException e){
			ClasseOutPut.setText("Iscriviti ad una classe");
		}
		
		
		
		
		JLabel lblNewLabel_1 = new JLabel("Task");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(10, 47, 73, 19);
		contentPane.add(lblNewLabel_1);
		
		
		//final JList ListaTask;
		//try {
		//	 ListaTask = new JList(GestioneClassiVirtuali.RestituisciClasseStudente(GestioneLogIn.getUtenteLoggato().getEmail()).getTask().toArray(new Task[0]));
		//}catch (NullPointerException e){
		//	 ListaTask = new JList();
		//}

		final JList ListaTask = (GestioneClassiVirtuali.RestituisciClasseStudente(GestioneLogIn.getUtenteLoggato().getEmail()) != null)
				? new JList(GestioneClassiVirtuali.RestituisciClasseStudente(GestioneLogIn.getUtenteLoggato().getEmail()).getTask().toArray(new Task[0]))
				: new JList();

		ListaTask.setBounds(10, 69, 73, 126);
		contentPane.add(ListaTask);
		
		JScrollPane scrollPane = new JScrollPane(ListaTask);
		scrollPane.setBounds(10, 69, 73, 126);
		contentPane.add(scrollPane);
		
		JButton BotCaricaSoluzione = new JButton("Carica Soluzione");
		BotCaricaSoluzione.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				if (ListaTask.getSelectedValue() != null) {
					CaricaSoluzioneFrame csf=new CaricaSoluzioneFrame((Task) ListaTask.getSelectedValue());
					csf.setVisible(true);
				}else OutPut.setText("Seleziona un Task");
			}
		});
		BotCaricaSoluzione.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotCaricaSoluzione.setBounds(91, 152, 146, 43);
		contentPane.add(BotCaricaSoluzione);
		
		JButton btnNewButton_2 = new JButton("Classifica");
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(GestioneClassiVirtuali.verificaIscrizioneStudente(GestioneLogIn.getUtenteLoggato().getEmail())){
					ClassificaFrame cf = new ClassificaFrame();
					cf.setVisible(true);
				}else OutPut.setText("Devi iscriverti ad una classe");

			}
		});
		btnNewButton_2.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		btnNewButton_2.setBounds(93, 69, 124, 73);
		contentPane.add(btnNewButton_2);

		
	}
}
