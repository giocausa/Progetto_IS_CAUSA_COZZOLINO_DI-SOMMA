package BoundaryMain;

import Control.GestioneClassiVirtuali;
import Control.GestioneLogIn;
import Control.GestioneStudenti;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AggStudenteStudente extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField CodiceText;
	private JTextField OutPut;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AggStudenteStudente frame = new AggStudenteStudente();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AggStudenteStudente() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Iscrizione Classe ");
		lblNewLabel.setFont(new Font("Source Sans Pro Semibold", Font.BOLD, 31));
		lblNewLabel.setBounds(10, 10, 234, 44);
		contentPane.add(lblNewLabel);
		
		CodiceText = new JTextField();
		CodiceText.setBounds(115, 79, 234, 29);
		contentPane.add(CodiceText);
		CodiceText.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Inserisci codice:");
		lblNewLabel_1.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(10, 79, 95, 29);
		contentPane.add(lblNewLabel_1);
		
		OutPut = new JTextField();
		OutPut.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		OutPut.setEditable(false);
		OutPut.setBounds(10, 209, 416, 44);
		contentPane.add(OutPut);
		OutPut.setColumns(10);
		
		JButton BotHome = new JButton("Home");
		BotHome.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				StudenteFrame sf = new StudenteFrame();
				sf.setVisible(true);
			}
		});
		BotHome.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotHome.setBounds(331, 10, 95, 44);
		contentPane.add(BotHome);
		
		JButton BotConferma = new JButton("Conferma");
		BotConferma.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (!GestioneClassiVirtuali.verificaIscrizioneStudente(GestioneLogIn.getUtenteLoggato().getEmail())) {
					if (GestioneClassiVirtuali.RestituisciClasseCodice(CodiceText.getText()) != null) {
						GestioneClassiVirtuali.RestituisciClasseCodice(CodiceText.getText()).addStudente(GestioneStudenti.TrovaStudente(GestioneLogIn.getUtenteLoggato().getEmail()));
						OutPut.setText("Sei stato aggiunto alla classe: " + (GestioneClassiVirtuali.RestituisciClasseCodice(CodiceText.getText()).getNome()));
					} else OutPut.setText("Codice non trovato");
				} else OutPut.setText("Sei già iscritto ad una classe");
			}
		});
		BotConferma.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotConferma.setBounds(134, 130, 171, 44);
		contentPane.add(BotConferma);
	}

}
