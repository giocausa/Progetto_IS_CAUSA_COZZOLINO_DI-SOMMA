package BoundaryMain;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import Control.GestioneSoluzioni;
import Control.GestioneTask;
import Entity.Soluzione;
import Entity.Task;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class ValutaTaskFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField TitoloOutPut;
	private JTextField PunteggioText;
	private JTextField PuntOutPut;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					//ValutaTaskFrame frame = new ValutaTaskFrame();
					//frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ValutaTaskFrame(Task t) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Valutazione Task");
		lblNewLabel.setFont(new Font("Source Sans Pro Semibold", Font.BOLD, 31));
		lblNewLabel.setBounds(10, 10, 238, 34);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Titolo task:");
		lblNewLabel_1.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(10, 54, 68, 23);
		contentPane.add(lblNewLabel_1);
		
		TitoloOutPut = new JTextField();
		TitoloOutPut.setEditable(false);
		TitoloOutPut.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		TitoloOutPut.setBounds(88, 55, 122, 23);
		contentPane.add(TitoloOutPut);
		TitoloOutPut.setColumns(10);
		TitoloOutPut.setText(t.getTitolo());
		
		JLabel lblNewLabel_1_1 = new JLabel("Descrizione:");
		lblNewLabel_1_1.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_1_1.setBounds(10, 84, 83, 23);
		contentPane.add(lblNewLabel_1_1);
		
		JTextArea DescOutPut = new JTextArea();
		DescOutPut.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		DescOutPut.setEditable(false);
		DescOutPut.setBounds(10, 107, 238, 130);
		contentPane.add(DescOutPut);
		DescOutPut.setText(t.getDescrizione());
		
		JScrollPane DescScroll = new JScrollPane(DescOutPut);
		DescScroll.setBounds(10, 107, 238, 65);
		contentPane.add(DescScroll);
		
		JPanel SoluzionePanel = new JPanel();
		SoluzionePanel.setBounds(263, 84, 163, 88);
		contentPane.add(SoluzionePanel);
		SoluzionePanel.setLayout(null);
		
		JTextArea OutPut = new JTextArea();
		OutPut.setEditable(false);
		OutPut.setBounds(0, 0, 163, 88);
		SoluzionePanel.add(OutPut);
		
		JScrollPane scrollPane = new JScrollPane(OutPut);
		scrollPane.setBounds(0, 0, 163, 88);
		SoluzionePanel.add(scrollPane);

		DefaultListModel<Soluzione> modello = new DefaultListModel<>();
		for (Soluzione s : t.getListaSoluzioni()) {
			modello.addElement(s);
		}


		JList <Soluzione>ListaStudenti = new JList<>(modello);
		ListaStudenti.setForeground(new Color(0, 0, 0));
		ListaStudenti.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		ListaStudenti.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		ListaStudenti.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String consegna = ((Soluzione) ListaStudenti.getSelectedValue()).getTesto();
				SoluzionePanel.setVisible(true);
				OutPut.setText(consegna);
			}
		});
//		ListaStudenti.setCellRenderer(new DefaultListCellRenderer() {
//			@Override
//			public Component getListCellRendererComponent(JList<?> list, Object value, int index,
//														  boolean isSelected, boolean cellHasFocus) {
//				JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
//				if (value instanceof Soluzione) {
//					label.setText(value.toString());  // forza l'uso di toString()
//				}
//				return label;
//			}
//		});
		//ListaStudenti.setBounds(10, 196, 238, 57);
		//contentPane.add(ListaStudenti);
		
		JScrollPane StudentiScoll = new JScrollPane(ListaStudenti);
		StudentiScoll.setBounds(10, 196, 238, 57);
		contentPane.add(StudentiScoll);
		
		JLabel lblNewLabel_1_2 = new JLabel("Consegne Studenti:");
		lblNewLabel_1_2.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_1_2.setBounds(10, 175, 122, 23);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Soluzione:");
		lblNewLabel_1_3.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_1_3.setBounds(263, 54, 68, 23);
		contentPane.add(lblNewLabel_1_3);
		
		PunteggioText = new JTextField();
		PunteggioText.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
			    if (!Character.isDigit(c)) {
			        e.consume();
			    }
			}
		});
		PunteggioText.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		PunteggioText.setBounds(263, 219, 60, 34);
		contentPane.add(PunteggioText);
		PunteggioText.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Punteggio Max:");
		lblNewLabel_2.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(264, 178, 92, 17);
		contentPane.add(lblNewLabel_2);
		
		PuntOutPut = new JTextField();
		PuntOutPut.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		PuntOutPut.setEditable(false);
		PuntOutPut.setBounds(366, 174, 60, 24);
		contentPane.add(PuntOutPut);
		PuntOutPut.setColumns(10);
		PuntOutPut.setText(Integer.toString(t.getPunteggioMax()));


		JButton BotOK = new JButton("OK");
		BotOK.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (!PunteggioText.getText().equals("")) {
					if(!ListaStudenti.isSelectionEmpty()){
						if (Integer.parseInt(PunteggioText.getText()) <= t.getPunteggioMax()) {
							PunteggioText.setBackground(Color.green);
							GestioneSoluzioni.AssegnaPunteggio(((Soluzione)ListaStudenti.getSelectedValue()),Integer.parseInt(PunteggioText.getText()));
							GestioneTask.setPunteggioDB(((Soluzione)ListaStudenti.getSelectedValue()),t,Integer.parseInt(PunteggioText.getText()));
							//GestioneTask.SpostaSoluzione(t,(Soluzione)ListaStudenti.getSelectedValue());
							GestioneTask.setConsegato((Soluzione)ListaStudenti.getSelectedValue(),t);
							//GestioneSoluzioni.AggiornaProgfilo(((Soluzione)ListaStudenti.getSelectedValue()));
							modello.removeElement((Soluzione)ListaStudenti.getSelectedValue());
						}else PunteggioText.setBackground(Color.red);
					}
				}
			}
		});
		BotOK.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotOK.setBounds(333, 219, 93, 34);
		contentPane.add(BotOK);
		
		JButton BotHome = new JButton("Home");
		BotHome.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DocentiFrame df = new DocentiFrame();
				df.setVisible(true);
			}
		});
		BotHome.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotHome.setBounds(341, 10, 85, 34);
		contentPane.add(BotHome);
		
		JLabel lblNewLabel_3 = new JLabel("Voto:");
		lblNewLabel_3.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(263, 202, 45, 13);
		contentPane.add(lblNewLabel_3);
		
		
	}
}
