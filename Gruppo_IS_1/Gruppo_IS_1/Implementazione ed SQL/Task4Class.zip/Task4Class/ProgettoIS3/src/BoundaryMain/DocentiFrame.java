package BoundaryMain;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JList;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;

import Control.GestioneClassiVirtuali;
import Control.GestioneDocenti;
import Control.GestioneLogIn;
import Entity.ClasseVirtuale;
import Entity.Task;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JScrollPane;

public class DocentiFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField OutPut;
	private JScrollPane TaskScroll;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DocentiFrame frame = new DocentiFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DocentiFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JList<ClasseVirtuale> ListaClassi = new JList(GestioneDocenti.TrovaDocente(GestioneLogIn.getUtenteLoggato().getEmail()).getClassi().toArray(new ClasseVirtuale[0]));
		ListaClassi.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		ListaClassi.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		ListaClassi.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		ListaClassi.setBounds(20, 43, 104, 210);
		contentPane.add(ListaClassi);
		
		JLabel lblNewLabel = new JLabel("Classi");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Source Sans Pro", Font.PLAIN, 21));
		lblNewLabel.setBounds(20, 10, 104, 23);
		contentPane.add(lblNewLabel);
		
		JButton BotAggiungiStudente = new JButton("Aggiungi Studente");
		BotAggiungiStudente.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				AggStudenteDocente AggStuDoFrame = new AggStudenteDocente();
				AggStuDoFrame.setVisible(true);
				
			}
		});
		BotAggiungiStudente.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotAggiungiStudente.setBounds(265, 43, 161, 30);
		contentPane.add(BotAggiungiStudente);
		
		JButton BotCreaTask = new JButton("Crea Task");		
		BotCreaTask.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				CreaTaskFrame ct = new CreaTaskFrame();
				ct.setVisible(true);
			}
		});
		BotCreaTask.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotCreaTask.setBounds(265, 83, 161, 30);
		contentPane.add(BotCreaTask);
		
		JButton BotCreaClasse = new JButton("Crea Classe");
		BotCreaClasse.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				CreaClasseFrame ccf = new CreaClasseFrame();
				ccf.setVisible(true);
			}
		});
		
		BotCreaClasse.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotCreaClasse.setBounds(146, 190, 104, 63);
		contentPane.add(BotCreaClasse);
		
		OutPut = new JTextField();
		OutPut.setEditable(false);
		OutPut.setBounds(265, 211, 161, 42);
		contentPane.add(OutPut);
		OutPut.setColumns(10);

		JList<Task> ListaTaskCreati = new JList(GestioneDocenti.TrovaDocente(GestioneLogIn.getUtenteLoggato().getEmail()).getTask().toArray(new Task[0]));
		ListaTaskCreati.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		ListaTaskCreati.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		ListaTaskCreati.setBounds(146, 43, 102, 137);
		contentPane.add(ListaTaskCreati);

		JButton BotAssegnaTask = new JButton("Assegna task");
		BotAssegnaTask.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (ListaClassi.getSelectedValue() != null) {
					if(ListaTaskCreati.getSelectedValue()!=null) {
						if(!ListaClassi.getSelectedValue().verificaTask(ListaTaskCreati.getSelectedValue().getTitolo())) {
							if (GestioneClassiVirtuali.addTask(ListaClassi.getSelectedValue(), ListaTaskCreati.getSelectedValue())) {
								OutPut.setText("Task Assegnato");
								ListaClassi.clearSelection();
								ListaTaskCreati.clearSelection();
							}
						}else {
							OutPut.setText("Task già inserito");
							ListaClassi.clearSelection();
							ListaTaskCreati.clearSelection();
						}
					}else OutPut.setText("Seleziona un task");
				}else OutPut.setText("Seleziona una classe");

			}
		});
		BotAssegnaTask.setToolTipText("");
		BotAssegnaTask.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		BotAssegnaTask.setBounds(265, 123, 161, 32);
		contentPane.add(BotAssegnaTask);
		
		JButton botValutaTask = new JButton("Valuta Task");
		botValutaTask.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(ListaTaskCreati.getSelectedValue()!=null) {
					ValutaTaskFrame vtf=new ValutaTaskFrame(ListaTaskCreati.getSelectedValue());
					vtf.setVisible(true);
				}else OutPut.setText("Seleziona un Task da valutare");
			}
		});
		botValutaTask.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		botValutaTask.setBounds(265, 165, 161, 29);
		contentPane.add(botValutaTask);
		
		JLabel lblListaTask = new JLabel("Task Create");
		lblListaTask.setFont(new Font("Source Sans Pro", Font.PLAIN, 21));
		lblListaTask.setBounds(146, 10, 104, 23);
		contentPane.add(lblListaTask);
		
		JButton btnNewButton = new JButton("x");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MainFrame mf=new MainFrame();
				mf.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 10));
		btnNewButton.setBackground(new Color(240, 240, 240));
		btnNewButton.setBounds(387, 10, 39, 30);
		contentPane.add(btnNewButton);
		
		
		
		JScrollPane ClassiScroll = new JScrollPane(ListaClassi);
		ClassiScroll.setBounds(20, 43, 104, 210);
		contentPane.add(ClassiScroll);
		
		
		JScrollPane TaskScroll = new JScrollPane(ListaTaskCreati);
		TaskScroll.setBounds(146, 43, 104, 137);
		contentPane.add(TaskScroll);
		
	}
}
