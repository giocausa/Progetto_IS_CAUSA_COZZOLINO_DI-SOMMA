package BoundaryMain;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;

import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPasswordField;

import Control.GestioneLogIn;

public class AccediFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField EmailText;
	private JPasswordField PassText;
	private JTextField Output;

	/**
	 * Launch the application.
	 */

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AccediFrame frame = new AccediFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AccediFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Accedi");
		lblNewLabel.setFont(new Font("Source Sans Pro Semibold", Font.BOLD, 31));
		lblNewLabel.setBounds(168, 10, 97, 40);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("E-mail:");
		lblNewLabel_1.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(88, 89, 45, 13);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password:");
		lblNewLabel_2.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(88, 135, 77, 13);
		contentPane.add(lblNewLabel_2);
		
		EmailText = new JTextField();
		EmailText.setBounds(187, 84, 177, 26);
		contentPane.add(EmailText);
		EmailText.setColumns(10);
		
		JButton BotConferma = new JButton("Conferma");
		BotConferma.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				

				if(GestioneLogIn.ControlloAccesso(EmailText.getText(), PassText.getText())) {
					GestioneLogIn.setUtenteLoggato(GestioneLogIn.getUtente(EmailText.getText(), PassText.getText()));
					if(GestioneLogIn.ControlloTipo(EmailText.getText(),PassText.getText())){
						Output.setText("Sei Studente");
						StudenteFrame StudenteFrame = new StudenteFrame();
						StudenteFrame.setVisible(true);
					}
					else {
						Output.setText("Sei Docente");
						DocentiFrame DocentiFrame = new DocentiFrame();
						DocentiFrame.setVisible(true);

					}
					//GestioneLogIn.setUtenteLoggato(GestioneLogIn.getUtente(email, pass));//ricorda l'utente loggato
				}else Output.setText("Credenziali incorrette");
			}
		});
		BotConferma.setFont(new Font("Tahoma", Font.PLAIN, 14));
		BotConferma.setBounds(88, 188, 114, 40);
		contentPane.add(BotConferma);
		
		PassText = new JPasswordField();
		PassText.setBounds(187, 126, 177, 26);
		contentPane.add(PassText);
		
		Output = new JTextField();
		Output.setEditable(false);
		Output.setBounds(239, 187, 187, 40);
		contentPane.add(Output);
		Output.setColumns(10);
		
	}
}
