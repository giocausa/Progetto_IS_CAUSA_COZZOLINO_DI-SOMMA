package BoundaryMain;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import java.awt.Color;

import Entity.Piattaforma;

public class MainFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */ 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame frame = new MainFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrame() {
		Piattaforma p =new Piattaforma();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(204, 255, 255));
		contentPane.setForeground(new Color(153, 255, 153));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Task4Class");
		lblNewLabel.setForeground(new Color(153, 51, 153));
		lblNewLabel.setFont(new Font("Source Sans Pro Semibold", Font.BOLD, 31));
		lblNewLabel.setBounds(139, 10, 156, 69);
		contentPane.add(lblNewLabel);
		
		JButton BotAccedi = new JButton("Accedi");
		BotAccedi.setBackground(new Color(153, 51, 153));
		BotAccedi.setForeground(new Color(153, 255, 255));
		BotAccedi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		BotAccedi.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				AccediFrame AccediFrame = new AccediFrame();
				AccediFrame.setVisible(true);
				
			}
		});
		BotAccedi.setFont(new Font("Tahoma", Font.PLAIN, 14));
		BotAccedi.setBounds(39, 181, 110, 37);
		contentPane.add(BotAccedi);
		
		JLabel lblNewLabel_1 = new JLabel("Sfida te stesso e scala la classifica!");
		lblNewLabel_1.setForeground(new Color(153, 51, 153));
		lblNewLabel_1.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(118, 71, 257, 21);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("La piattaforma che trasforma i compiti in punteggio ");
		lblNewLabel_2.setForeground(new Color(153, 51, 153));
		lblNewLabel_2.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(72, 89, 330, 37);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("e i punteggi in motivazione.");
		lblNewLabel_3.setForeground(new Color(153, 51, 153));
		lblNewLabel_3.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(139, 116, 211, 26);
		contentPane.add(lblNewLabel_3);
		
		JButton BotRegistrati = new JButton("Registrati");
		BotRegistrati.setForeground(new Color(153, 255, 255));
		BotRegistrati.setBackground(new Color(153, 51, 153));
		BotRegistrati.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				RegistratiFrame RegistratiFrame = new RegistratiFrame();
				RegistratiFrame.setVisible(true);
				
			}
		});
		
		BotRegistrati.setFont(new Font("Tahoma", Font.PLAIN, 14));
		BotRegistrati.setBounds(277, 181, 110, 37);
		contentPane.add(BotRegistrati);
	}
}
