package BoundaryMain;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JList;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;

import java.awt.Font;
import javax.swing.JLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import Control.GestioneClassiVirtuali;
import Control.GestioneDocenti;
import Control.GestioneLogIn;
import Entity.ClasseVirtuale;
import javax.swing.JButton;

public class AggStudenteDocente extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField emailText;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AggStudenteDocente frame = new AggStudenteDocente();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AggStudenteDocente() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JList<ClasseVirtuale> ListaClassi = new JList<>(GestioneDocenti.TrovaDocente(GestioneLogIn.getUtenteLoggato().getEmail()).getClassi().toArray(new ClasseVirtuale[0]));
		ListaClassi.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		ListaClassi.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		ListaClassi.setFont(new Font("Source Sans Pro", Font.PLAIN, 16));
		ListaClassi.setBounds(10, 85, 147, 168);
		contentPane.add(ListaClassi);
		
		emailText = new JTextField();
		emailText.setBounds(180, 85, 204, 42);
		contentPane.add(emailText);
		emailText.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Aggiungi Studente");
		lblNewLabel.setFont(new Font("Source Sans Pro Semibold", Font.BOLD, 27));
		lblNewLabel.setBounds(10, 10, 223, 42);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Seleziona una classe");
		lblNewLabel_1.setFont(new Font("Source Serif Pro", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(10, 62, 147, 13);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Inserisci l'email dello studente:");
		lblNewLabel_1_1.setFont(new Font("Source Serif Pro", Font.PLAIN, 14));
		lblNewLabel_1_1.setBounds(180, 62, 204, 13);
		contentPane.add(lblNewLabel_1_1);
		
		JButton BotConfemra = new JButton("Conferma");
		BotConfemra.setFont(new Font("Source Sans Pro", Font.PLAIN, 18));
		BotConfemra.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ClasseVirtuale c =ListaClassi.getSelectedValue();
				if (c!=null){
					if (!GestioneClassiVirtuali.verificaIscrizioneStudente(emailText.getText())){
						if (GestioneClassiVirtuali.addStudente(c, emailText.getText())){
							textField_1.setText("Studente aggiunto");
						}else textField_1.setText("Email non trovata");
					}else textField_1.setText("Studente già inesrito");
				}else textField_1.setText("seleziona una classe");
			}
		});
		BotConfemra.setBounds(180, 145, 204, 42);
		contentPane.add(BotConfemra);
		
		textField_1 = new JTextField();
		textField_1.setEditable(false);
		textField_1.setBounds(180, 211, 204, 42);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnNewButton = new JButton("Home");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				BoundaryMain.DocentiFrame DocentiFrame= new BoundaryMain.DocentiFrame();
				DocentiFrame.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Source Sans Pro", Font.PLAIN, 14));
		btnNewButton.setBounds(297, 10, 87, 27);
		contentPane.add(btnNewButton);
	}
}
