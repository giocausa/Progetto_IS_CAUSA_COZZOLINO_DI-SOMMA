package Control;

import Entity.*;

public class GestioneStudenti {

    public static Studente TrovaStudente(String email){
        return Piattaforma.TrovaStudente(email);
    }

    //public static float getMedia(){return getMedia();}
    //public static int getPunteggioTotale(Studente s){return s.getProfilo.getPunteggioTotale;}
    //public static int getTaskCompletati(Studente s){return s.getProfilo.getTaskCompletati;}



}
