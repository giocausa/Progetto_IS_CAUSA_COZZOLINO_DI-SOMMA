package Control;

import Entity.ClasseVirtuale;
import Entity.Docente;
import Entity.Piattaforma;
import Entity.Studente;
import Entity.Task;

public class GestioneClassiVirtuali {
	
	public static boolean creaClasseVirtuale(Docente d, String nome, String codice) {
        if (!Piattaforma.CercaClasse(codice)) {
            ClasseVirtuale c = new ClasseVirtuale(nome, codice);
            Piattaforma.addClasseVirtuale(c);
            d.getClassi().add(c);
            c.salvaSuDatabase(d);
            return true;
        }else  return false;
	}

    public static boolean addStudente(ClasseVirtuale classe, String email) {
        Studente s =GestioneStudenti.TrovaStudente(email);
        if (s != null) {
            classe.addStudente(s);
            return true;
        } else {return false;}
    }
    
    public static boolean addTask(ClasseVirtuale classe, Task t) {
        	if (!GestioneTask.CercataskClasse(classe, t.getTitolo())) {

        		Piattaforma.addTask(t);
        		classe.addTask(t);
                return true;
        	} else return false;
    }
    

    public static boolean verificaIscrizioneStudente (String email){
        for (ClasseVirtuale c: Piattaforma.listaClasseVirtuale){
            if(c.verificaStudente(email))return true;

        }return false;
    }

    public static ClasseVirtuale RestituisciClasseStudente (String email){
        for (ClasseVirtuale c: Piattaforma.listaClasseVirtuale){
            if(c.verificaStudente(email))return c;
        }return null;
    }

    public static ClasseVirtuale RestituisciClasseCodice (String cod){
        for (ClasseVirtuale c: Piattaforma.listaClasseVirtuale){
            if(c.getCodUnivoco().equals(cod))return c;
        }return null;
    }


}
