package Control;
import Entity.ClasseVirtuale;
import Entity.Docente;
import Entity.Piattaforma;
import Entity.Studente;

import java.util.ArrayList;

public class GestioneDocenti {

    //public ArrayList<ClasseVirtuale> getClassi(Docente d){
    //    return d.getClassi();
    //}

    public static Docente TrovaDocente(String email){
        return Piattaforma.TrovaDocente(email);
    }

}
