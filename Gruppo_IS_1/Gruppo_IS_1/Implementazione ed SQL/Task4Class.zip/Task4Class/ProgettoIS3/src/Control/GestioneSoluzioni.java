package Control;

import Database.SoluzioneDAO;
import Entity.Soluzione;
import Entity.Studente;
import Entity.Task;

import java.util.ArrayList;

public class GestioneSoluzioni {

    public static Soluzione CreaSoluzione(Studente stu, String testo){
        Soluzione s = new Soluzione(testo,stu);
        return s;
    }

    public static boolean aggiungiSoluzione(Task t, Soluzione s){
        if (t.aggiungiSoluzione(t.getTitolo(),s)){
            t.addSoluzioni(s);
            s.salvaSoluzioneSuDB(s,t.getTitolo());
            t.Aggiornalista();
           // t.listaSoluzioniCorrette = (ArrayList<Soluzione>) SoluzioneDAO.getSoluzioniConsegnatePerTask(titolo);
            return true;
        }else return false;
    }
    //public static boolean TrovaSoluzione(Task t, Soluzione s){
      //  for(int i=0; i<t.getListaSoluzioni().size(); i++){
        //    if(t.getListaSoluzioni().get(i).getStudente().getEmail().equals(s.getStudente().getEmail())){
          //      return true;
            //}
        //}return false;
    //}

    public static void AssegnaPunteggio(Soluzione s, int p){
        s.setPunteggio(s.getStudente().getEmail(),p);
        //s.getStudente().getProfilo().aggiornaProfiloSuDB(s.getStudente().getEmail());
    }
    public static void AggiornaProgfilo(Soluzione s){
        s.getStudente().getProfilo().aggiornaProfiloSuDB(s.getStudente().getEmail());
    }

}
