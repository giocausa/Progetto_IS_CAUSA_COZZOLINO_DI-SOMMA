package Entity;
import Database.ClasseVirtualeDAO;
import Database.DocenteDAO;
import Database.StudenteDAO;
import Database.TaskDAO;
import Database.ClasseVirtualeDAO;

import java.util.ArrayList;

public class Piattaforma {
	//private static Docente d = new Docente("Dome","Di Somma","dodiso","ciao",false);
    private static Utente utenteLoggato;
    public static ArrayList<Utente> listaUtenti;
    public static ArrayList<Docente> listaDocenti;
    public static ArrayList<Studente> listaStudenti;
    public static ArrayList<ClasseVirtuale> listaClasseVirtuale;
    public static ArrayList<Task> listaTask;
    //public static ArrayList<Soluzione> listaSoluzione;
    //private static Docente d; //= new Docente("Dome","Di Somma","dodiso","ciao",false);
    

    public Piattaforma() {
    	this.utenteLoggato=null;
    	this.listaUtenti= new ArrayList();
    	this.listaDocenti= (ArrayList<Docente>) DocenteDAO.getTuttiIDocenti();
        this.listaStudenti=  (ArrayList<Studente>) StudenteDAO.getTuttiGliStudenti();
        this.listaUtenti.addAll(listaDocenti);
        this.listaUtenti.addAll(listaStudenti);
        this.listaClasseVirtuale= (ArrayList<ClasseVirtuale>) ClasseVirtualeDAO.getTutteLeClassi();
        this.listaTask= (ArrayList<Task>) TaskDAO.getTuttiITask();
        //this.listaSoluzione= new ArrayList();

    }


    public static void setUtenteLoggato(Utente u) {
        utenteLoggato = u;
    }
    public static Utente getUtenteLoggato() {
        return utenteLoggato;
    }
    public static void addUtente(Utente u){
        listaUtenti.add(u);
    }
    public static void addStudente(Studente s){
        StudenteDAO.salvaInDB(s);
        listaStudenti.add(s);
    }
    public static void addDocente(Docente d){
        DocenteDAO.salvaInDB(d);
        listaDocenti.add(d);
    }

    public static void addClasseVirtuale(ClasseVirtuale v){
        listaClasseVirtuale.add(v);}
    public static void addTask(Task t){
        listaTask.add(t);}
    //public  static void addSoluzione(Soluzione s){listaSoluzione.add(s);}


    //public static ArrayList<Utente> getUtenti(){
        //return listaUtenti;
    //}

    public static boolean UtentePresente(String email){
            for (Utente u : listaUtenti) {
                if (u.getEmail().equals(email)) {
                    return true;
                }
            }
            return false;
        }

    public static Utente ControlloAccesso(String email, String pass){
        for (Utente u : listaUtenti) {
            if (u.getEmail().equals(email)){
                if (u.getPass().equals(pass)) return u;
            }
        } return null;

    }

    public static Studente TrovaStudente(String email){
        for (Studente u : listaStudenti) {
            if (u.getEmail().equals(email)){return u;}
        } return null;
    }

    public static Docente TrovaDocente(String email){
        for (Docente u : listaDocenti) {
            if (u.getEmail().equals(email)){return u;}
        } return null;
    }

    public static boolean CercaClasse(String cod){
        for (ClasseVirtuale v : listaClasseVirtuale) {
            if (v.getCodUnivoco().equals(cod)) return true;
        }return false;
    }
    
    public static boolean CercaTask(String titolo) {
        if (listaTask.isEmpty()) return false;
        else{
            for (Task v : listaTask) {
                if (v.getTitolo().equals(titolo)) return true;
            }return false;
        }
    }
    
  

}
