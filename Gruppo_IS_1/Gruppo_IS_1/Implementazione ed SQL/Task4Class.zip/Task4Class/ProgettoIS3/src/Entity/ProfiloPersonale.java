package Entity;
import Database.ProfiloPersonaleDAO;

public class ProfiloPersonale {
    private int contMedia;
    private int punteggioTotale;
    private float MediaVoti;
    private int TaskCompletati;
    private transient ProfiloPersonaleDAO profiloDAO=new ProfiloPersonaleDAO();

    public ProfiloPersonale(){
        this.contMedia=0;
        this.punteggioTotale=0;
        this.TaskCompletati=0;
        this.MediaVoti=0;
    }


    public float getMediaVoti(){
        return this.MediaVoti;
    }

    public int getTaskCompletati(){
        return this.TaskCompletati;
    }

    public int getPunteggioTotale(){
        return this.punteggioTotale;
    }


    public void setPunteggioTotale(String email,int p){
        this.punteggioTotale=this.punteggioTotale+p;
        this.contMedia=this.contMedia+1;
        this.MediaVoti=this.punteggioTotale/this.contMedia;
        System.out.println(this.punteggioTotale+this.MediaVoti+this.contMedia);
        profiloDAO.aggiornaProfilo(email,this);
    }
    public void setPunteggioTotaleDB(int p){
        this.punteggioTotale=p;
    }

    public void setTaskCompletati(String s){
        this.TaskCompletati=this.TaskCompletati+1;
        profiloDAO.aggiornaProfilo(s,this);
    }

    public int salvaProfiloSuDB(String emailStudente) {
        return profiloDAO.salvaProfilo(emailStudente, this);
    }

    // Metodo per aggiornare il profilo nel DB
    public int aggiornaProfiloSuDB(String emailStudente) {
        return profiloDAO.aggiornaProfilo(emailStudente,this);
    }

    public int getContMedia() {
        return this.contMedia;
    }

    public void setMediaVotiDB(float mediaVoti) {
        this.MediaVoti=mediaVoti;
    }

    public void setTaskCompletatiDB(int taskCompletati) {
        this.TaskCompletati=taskCompletati;
    }

    public void setContMediaDB(int contMedia) {
        this.contMedia=contMedia;
    }
}
