package Entity;

import java.util.Comparator;
import java.util.Objects;
import Database.StudenteDAO;

public class Studente extends Utente {
    private ProfiloPersonale profilo;
    private transient StudenteDAO dao = new StudenteDAO();

    public Studente(String n, String c, String e, String p, boolean r) {
        super(n, c, e, p, r);
        this.profilo = new ProfiloPersonale();
    }

    public Studente(String n, String c, String e, String p, boolean r, ProfiloPersonale profilo) {
        super(n, c, e, p, r);
        this.profilo = profilo;
        if (profilo != null) {
            System.out.println("Costruttore Studente: profiloPersonale = " +
                    profilo.getTaskCompletati() + profilo.getMediaVoti() + profilo.getPunteggioTotale());
        } else {
            System.out.println("Costruttore Studente: profiloPersonale = null");
        }
    }

    public ProfiloPersonale getProfilo() {
        return this.profilo;
    }

    public static Comparator<Studente> comparatorePerPunteggioTotale = new Comparator<Studente>() {
        @Override
        public int compare(Studente s1, Studente s2) {
            return Float.compare(s2.profilo.getPunteggioTotale(), s1.profilo.getPunteggioTotale());
        }
    };

    public static Comparator<Studente> comparatorePerTaskCompletati = new Comparator<Studente>() {
        @Override
        public int compare(Studente s1, Studente s2) {
            return Integer.compare(s2.profilo.getTaskCompletati(), s1.profilo.getTaskCompletati());
        }
    };

    @Override
    public String toString() {
        return getNome() + " " + getCognome();
    }
    @Override
    public boolean equals(Object o) {
        return super.equals(o);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    public int salvaSuDatabase() {
        return dao.salvaInDB(this);
    }

    public Studente trovaStudentePerEmail(String email) {
        StudenteDAO dao = new StudenteDAO();
        return dao.trovaPerEmail(email);
    }

    public static java.util.List<Studente> getTuttiGliStudenti() {
        StudenteDAO dao = new StudenteDAO();
        return dao.getTuttiGliStudenti();
    }

    public void setProfilo(ProfiloPersonale profilo) {
        this.profilo=profilo;
    }
}
