package Entity;

import java.util.ArrayList;

import Database.ClasseVirtualeDAO;
import Database.DocenteDAO;
import Database.TaskDAO;

public class Docente extends Utente {

    private  ArrayList<ClasseVirtuale> classi;
    private  ArrayList<Task> task;

    //Collegamento dao
    private transient DocenteDAO dao= new DocenteDAO();

    public Docente(String n, String c, String e, String p, boolean r){
        super (n,c,e,p,r);
        this.classi= (ArrayList<ClasseVirtuale>) ClasseVirtualeDAO.getClassiByDocenteEmail(e);
        this.task= (ArrayList<Task>) TaskDAO.getTaskByDocenteEmail(e);
    }

    public ArrayList<ClasseVirtuale> getClassi() {
        return classi;
    }
    public ArrayList<Task> getTask() {
        return task;
    }



    // Metodo per salvare il docente su DB
    public int salvaSuDatabase() {
        return dao.salvaInDB(this);
    }

    // Metodo per eliminare docente da DB tramite email


    // Metodo statico per trovare docente tramite email
    public static Docente trovaDocentePerEmail(String email) {
        DocenteDAO dao = new DocenteDAO();
        return dao.trovaPerEmail(email);
    }

    // Metodo statico per recuperare tutti i docenti
    public ArrayList<Docente> getTuttiIDocenti() {

        return new ArrayList<>(dao.getTuttiIDocenti());
    }

}
