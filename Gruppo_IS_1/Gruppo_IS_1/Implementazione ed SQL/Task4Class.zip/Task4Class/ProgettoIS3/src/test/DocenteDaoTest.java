package test;

import Database.DocenteDAO;
import Entity.Docente;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.List;
import java.util.UUID;

import static org.junit.Assert.*;

public class DocenteDaoTest {

    private Docente docenteTest;
    private String emailUnica;

    @Before
    public void setUp() {
        // Genera un'email unica per evitare conflitti
        emailUnica = "test_" + UUID.randomUUID() + "@test.com";
        docenteTest = new Docente("Daria", "Cozzolino", emailUnica, "puteoli", true);

        int result = DocenteDAO.salvaInDB(docenteTest);
        assertTrue("Inserimento docente fallito", result > 0);
    }

    @After
    public void tearDown() {
        if (docenteTest != null && docenteTest.getEmail() != null) {
            DocenteDAO dao = new DocenteDAO();
            int result = dao.eliminaDocente(docenteTest.getEmail());
            assertTrue("Eliminazione docente fallita", result >= 0);
        }
    }

    @Test
    public void testTrovaPerEmail() {
        DocenteDAO dao = new DocenteDAO();
        Docente trovato = dao.trovaPerEmail(docenteTest.getEmail());
        assertNotNull("Docente non trovato", trovato);
        assertEquals("Email errata", docenteTest.getEmail(), trovato.getEmail());
    }

    @Test
    public void testGetTuttiIDocenti() {
        List<Docente> docenti = DocenteDAO.getTuttiIDocenti();
        assertNotNull("Lista docenti nulla", docenti);
        assertTrue("Lista docenti vuota", docenti.size() > 0);
    }

    @Test
    public void testGetClassi() {
        List<?> classi = docenteTest.getClassi();
        assertNotNull("Lista classi nulla", classi);
    }

    @Test
    public void testGetTask() {
        List<?> task = docenteTest.getTask();
        assertNotNull("Lista task nulla", task);
    }
}
