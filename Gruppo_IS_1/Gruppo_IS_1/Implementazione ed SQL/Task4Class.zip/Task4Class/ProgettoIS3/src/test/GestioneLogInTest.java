package test;

import Control.GestioneLogIn;
import Database.DocenteDAO;
import Database.ProfiloPersonaleDAO;
import Database.StudenteDAO;
import Entity.Piattaforma;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.UUID;

import static org.junit.Assert.*;

public class GestioneLogInTest {

    private String emailStudente;
    private String emailDocente;

    private final StudenteDAO studenteDAO = new StudenteDAO();
    private final DocenteDAO docenteDAO = new DocenteDAO();
    private final ProfiloPersonaleDAO profiloDAO = new ProfiloPersonaleDAO();

    @Before
    public void setUp() {
        new Piattaforma();
        if (Piattaforma.listaUtenti == null) {
            Piattaforma.listaUtenti = new ArrayList<>();
        }

        // Email uniche per evitare duplicati
        emailStudente = "studente_test_" + UUID.randomUUID() + "@test.com";
        emailDocente = "docente_test_" + UUID.randomUUID() + "@test.com";

        String resStudente = GestioneLogIn.creaUtente("Mario", "Rossi", emailStudente, "password123", true);
        String resDocente = GestioneLogIn.creaUtente("Luca", "Verdi", emailDocente, "password456", false);

        assertEquals("Studente aggiunto!", resStudente);
        assertEquals("Docente aggiunto!", resDocente);
    }

    @After
    public void tearDown() {
        if (emailStudente != null) {
            profiloDAO.eliminaProfiloPersonale(emailStudente);  // Studente ha profilo
            studenteDAO.eliminaStudente(emailStudente);
        }

        if (emailDocente != null) {
            docenteDAO.eliminaDocente(emailDocente);
        }
    }

    @Test
    public void testControllaUtentePresenteENonPresente() {
        assertTrue(GestioneLogIn.ControllaUtente(emailStudente));
        assertFalse(GestioneLogIn.ControllaUtente("non_esiste@test.com"));
    }

    @Test
    public void testControlloAccessoCorrettoEErrato() {
        assertTrue(GestioneLogIn.ControlloAccesso(emailStudente, "password123"));
        assertFalse(GestioneLogIn.ControlloAccesso(emailStudente, "passwordErrata"));
    }

    @Test
    public void testControlloTipoStudenteEDocente() {
        assertTrue(GestioneLogIn.ControlloTipo(emailStudente, "password123")); // Studente
        assertFalse(GestioneLogIn.ControlloTipo(emailDocente, "password456")); // Docente
    }

    @Test
    public void testGetUtenteValidoENullo() {
        assertNotNull(GestioneLogIn.getUtente(emailStudente, "password123"));
        assertNull(GestioneLogIn.getUtente("non_esiste@test.com", "pass"));
    }

    @Test
    public void testSetEGetUtenteLoggato() {
        GestioneLogIn.setUtenteLoggato(GestioneLogIn.getUtente(emailDocente, "password456"));
        assertNotNull(GestioneLogIn.getUtenteLoggato());
        assertEquals(emailDocente, GestioneLogIn.getUtenteLoggato().getEmail());
    }
}
