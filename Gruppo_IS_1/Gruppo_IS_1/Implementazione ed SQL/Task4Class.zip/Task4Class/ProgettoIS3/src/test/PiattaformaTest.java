package test;
import Entity.*;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;

import static org.junit.Assert.*;


public class PiattaformaTest {
    Entity.Piattaforma piattaforma;
    Docente docente;
    Studente studente;
    Task task;
    ClasseVirtuale classeVirtuale;
    //Utente utente;

    @Before
    public void setUp() throws Exception {
        piattaforma=new Piattaforma();
        assertFalse(piattaforma==null);
        docente=new Docente("gino","cappuccino","emaildocente","password",false);
        assertFalse(docente==null);
        task=new Task("titolo","descrizione",100,new Data(21,11,2026));
        assertFalse(task==null);
        studente=new Studente("nome","cognome","emailstudente","password",true);
        assertFalse(studente==null);
        classeVirtuale=new ClasseVirtuale("4D","ABC23");
        assertFalse(classeVirtuale==null);


    }

    @Test
    public void testAggiuntaUtenteStudente() {
        piattaforma.addUtente(studente);
        assertTrue(piattaforma.UtentePresente(studente.getEmail()));
    }

    @Test
    public void testAggiuntaUtenteDocente() {
        piattaforma.addUtente(docente);
        assertTrue(piattaforma.UtentePresente(docente.getEmail()));
    }

    @Test
    public void testUtenteNonPresente() {
        assertFalse(piattaforma.UtentePresente("123456789"));
    }

    // --- STUDENTI ---

    @Test
    public void testAggiuntaStudente() {
        piattaforma.addStudente(studente);
        assertEquals(studente, piattaforma.TrovaStudente(studente.getEmail()));
    }

    @Test
    public void testRicercaStudenteInesistente() {
        assertNull(piattaforma.TrovaStudente("123456789"));
    }

    // --- DOCENTI ---

    @Test
    public void testAggiuntaDocente() {
        piattaforma.addDocente(docente);
        assertEquals(docente, piattaforma.TrovaDocente(docente.getEmail()));
    }

    @Test
    public void testRicercaDocenteInesistente() {
        assertNull(piattaforma.TrovaDocente("123456789"));
    }

    // --- TASK ---

    @Test
    public void testAggiuntaTask() {
        piattaforma.addTask(task);
        assertTrue(piattaforma.CercaTask(task.getTitolo()));
    }

    @Test
    public void testTaskInesistente() {
        assertFalse(piattaforma.CercaTask("123456789"));
    }

    // --- CLASSE VIRTUALE ---

    @Test
    public void testAggiuntaClasseVirtuale() {
        piattaforma.addClasseVirtuale(classeVirtuale);
        assertTrue(piattaforma.CercaClasse(classeVirtuale.getCodUnivoco()));
    }

    @Test
    public void testClasseInesistente() {
        assertFalse(piattaforma.CercaClasse("123456789"));
    }

    // --- CONTROLLO ACCESSO ---

    @Test
    public void testControlloAccessoValidoStudente() {
        piattaforma.addUtente(studente);
        assertEquals(studente, piattaforma.ControlloAccesso(studente.getEmail(), studente.getPass()));
    }

    @Test
    public void testControlloAccessoValidoDocente() {
        piattaforma.addUtente(docente);
        assertEquals(docente, piattaforma.ControlloAccesso(docente.getEmail(), docente.getPass()));
    }

    @Test
    public void testControlloAccessoFallito() {
        assertNull(piattaforma.ControlloAccesso("123456789", "123456789"));
    }


    @After
    public void tearDown() throws Exception {
        piattaforma=null;
        assertTrue(piattaforma==null);
        docente=null;
        assertTrue(docente==null);
        studente=null;
        assertTrue(studente==null);
        classeVirtuale=null;
        assertTrue(classeVirtuale==null);
        task=null;
        assertTrue(task==null);
    }






}
