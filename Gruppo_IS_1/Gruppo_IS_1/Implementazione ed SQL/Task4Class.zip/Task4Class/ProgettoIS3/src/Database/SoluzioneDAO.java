package Database;

import Entity.Soluzione;
import Entity.Data;
import Entity.Studente;
import Entity.ProfiloPersonale;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SoluzioneDAO {

    public int salvaSoluzione(Soluzione s, String taskTitolo) {
        int ret = 0;
        String query = "INSERT INTO soluzione (testo, punteggio, Data, Studente_email, Consegnato, Task_Titolo) VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = DBConnectionManager.getConnection().prepareStatement(query)) {
            String dataString = s.getData().getAnno() + "-" +
                    String.format("%02d", s.getData().getMese()) + "-" +
                    String.format("%02d", s.getData().getGiorno());
            stmt.setString(1, s.getTesto());
            stmt.setInt(2, s.getPunteggio());
            stmt.setDate(3, Date.valueOf(dataString));
            stmt.setString(4, s.getStudente().getEmail());
            stmt.setBoolean(5, false); // Consegnato = 0
            stmt.setString(6, taskTitolo);

            ret = stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            ret = -1;
        }

        return ret;
    }

    public static boolean updatePunteggioSoluzione(String studenteEmail, String taskTitolo, int nuovoPunteggio) {
        String query = "UPDATE soluzione SET punteggio = ? WHERE Studente_email = ? AND Task_Titolo = ?";

        try (PreparedStatement stmt = DBConnectionManager.getConnection().prepareStatement(query)) {
            stmt.setInt(1, nuovoPunteggio);
            stmt.setString(2, studenteEmail);
            stmt.setString(3, taskTitolo);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean setSoluzioneNonConsegnata(String studenteEmail, String taskTitolo) {
        String query = "UPDATE soluzione SET Consegnato = 1 WHERE Studente_email = ? AND Task_Titolo = ?";

        try (PreparedStatement stmt = DBConnectionManager.getConnection().prepareStatement(query)) {
            stmt.setString(1, studenteEmail);
            stmt.setString(2, taskTitolo);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<Soluzione> getSoluzioniConsegnatePerTask(String taskTitolo) {
        return getSoluzioniPerTaskConFiltroCorrette(taskTitolo, true);
    }

    public static List<Soluzione> getSoluzioniNonConsegnatePerTask(String taskTitolo) {
        return getSoluzioniPerTaskConFiltroCorrette(taskTitolo, false);
    }

    public static List<Soluzione> getSoluzioniPerTaskConFiltroCorrette(String taskTitolo, boolean corretto) {
        List<Soluzione> soluzioni = new ArrayList<>();
        String query = "SELECT s.testo, s.punteggio, s.Data, s.Studente_email, s.Consegnato, st.nome, st.cognome " +
                "FROM soluzione s JOIN studente st ON s.Studente_email = st.email " +
                "WHERE s.Task_Titolo = ? AND s.Consegnato = ?";

        try (PreparedStatement stmt = DBConnectionManager.getConnection().prepareStatement(query)) {
            stmt.setString(1, taskTitolo);
            stmt.setBoolean(2, corretto);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Date dataDB = rs.getDate("Data");
                Data data = null;
                if (dataDB != null) {
                    data = new Data(dataDB.toLocalDate().getDayOfMonth(),
                            dataDB.toLocalDate().getMonthValue(),
                            dataDB.toLocalDate().getYear());
                }

                String email = rs.getString("Studente_email");
                String nome = rs.getString("nome");
                String cognome = rs.getString("cognome");
                Studente studente = new Studente(nome, cognome, email, "", true);
                ProfiloPersonale profilo = ProfiloPersonaleDAO.caricaProfilo(email);
                if (profilo != null) {
                    studente.setProfilo(profilo);
                }

                Soluzione sol = new Soluzione(
                        rs.getString("testo"),
                        rs.getInt("punteggio"),
                        data,
                        studente,
                        rs.getBoolean("Consegnato")
                );

                soluzioni.add(sol);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return soluzioni;
    }

    public static boolean studenteHaGiaConsegnato(String studenteEmail, String taskTitolo) {
        String query = "SELECT COUNT(*) FROM soluzione WHERE Studente_email = ? AND Task_Titolo = ?";

        try (PreparedStatement stmt = DBConnectionManager.getConnection().prepareStatement(query)) {
            stmt.setString(1, studenteEmail);
            stmt.setString(2, taskTitolo);
            ResultSet rs = stmt.executeQuery();
            return rs.next() && rs.getInt(1) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
}
