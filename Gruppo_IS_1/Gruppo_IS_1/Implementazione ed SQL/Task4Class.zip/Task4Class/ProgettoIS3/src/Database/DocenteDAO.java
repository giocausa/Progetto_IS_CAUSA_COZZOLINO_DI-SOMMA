package Database;

import Entity.Docente;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DocenteDAO {

    public static int salvaInDB(Docente d) {
        int ret = 0;
        String query = "INSERT INTO docente (nome, cognome, email, password, ruolo) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = DBConnectionManager.getConnection().prepareStatement(query)) {
            stmt.setString(1, d.getNome());
            stmt.setString(2, d.getCognome());
            stmt.setString(3, d.getEmail());
            stmt.setString(4, d.getPass());
            stmt.setInt(5, 0); // ruolo docente
            ret = stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            ret = -1;
        }

        return ret;
    }

    public int eliminaDocente(String email) {
        int ret = 0;
        String query = "DELETE FROM docente WHERE email = ?";

        try (PreparedStatement stmt = DBConnectionManager.getConnection().prepareStatement(query)) {
            stmt.setString(1, email);
            ret = stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            ret = -1;
        }

        return ret;
    }

    public Docente trovaPerEmail(String email) {
        Docente docente = null;
        String query = "SELECT nome, cognome, email, password FROM docente WHERE email = ?";

        try (PreparedStatement stmt = DBConnectionManager.getConnection().prepareStatement(query)) {
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                docente = new Docente(
                        rs.getString("nome"),
                        rs.getString("cognome"),
                        rs.getString("email"),
                        rs.getString("password"),
                        false // ruolo docente
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return docente;
    }

    public static List<Docente> getTuttiIDocenti() {
        List<Docente> docenti = new ArrayList<>();
        String query = "SELECT nome, cognome, email, password FROM docente";

        try (PreparedStatement stmt = DBConnectionManager.getConnection().prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Docente d = new Docente(
                        rs.getString("nome"),
                        rs.getString("cognome"),
                        rs.getString("email"),
                        rs.getString("password"),
                        false
                );
                docenti.add(d);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return docenti;
    }
}
