package Database;

import Entity.ClasseVirtuale;
import Entity.Docente;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClasseVirtualeDAO {

    public static int salvaClasse(ClasseVirtuale c, Docente d) {
        int ret = 0;

        String query = "INSERT INTO classevirtuale (nome, codiceunivoco, Docente_email) VALUES (\""
                + c.getNome() + "\", \""
                + c.getCodUnivoco() + "\", \""
                + d.getEmail() + "\")";

        System.out.println(query);

        try {
            ret = DBConnectionManager.updateQuery(query);
        } catch (SQLException e) {
            e.printStackTrace();
            ret = -1;
        }

        return ret;
    }

    public static List<ClasseVirtuale> getClassiByDocenteEmail(String emailDocente) {
        List<ClasseVirtuale> classi = new ArrayList<>();

        String query = "SELECT nome, codiceunivoco FROM classevirtuale WHERE Docente_email = \"" + emailDocente + "\"";
        System.out.println(query);

        try {
            ResultSet rs = DBConnectionManager.selectQuery(query);
            while (rs.next()) {
                ClasseVirtuale c = new ClasseVirtuale(
                        rs.getString("nome"),
                        rs.getString("codiceunivoco")
                );
                classi.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return classi;
    }

    public static List<ClasseVirtuale> getTutteLeClassi() {
        List<ClasseVirtuale> classi = new ArrayList<>();

        String query = "SELECT nome, codiceunivoco FROM classevirtuale";
        System.out.println(query);

        try {
            ResultSet rs = DBConnectionManager.selectQuery(query);
            while (rs.next()) {
                ClasseVirtuale c = new ClasseVirtuale(
                        rs.getString("nome"),
                        rs.getString("codiceunivoco")
                );
                classi.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return classi;
    }
}
