package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnectionManager {

	private static final String url = "jdbc:mysql://localhost:3306/dbis";
	private static final String driver = "com.mysql.cj.jdbc.Driver";
	private static final String userName = "root";
	private static final String password = "root";


	static {
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}


	// Metodo per ottenere una connessione con autocommit attivato
	public static Connection getConnection() throws SQLException {
		Connection conn = DriverManager.getConnection(url, userName, password);
		conn.setAutoCommit(true);
		return conn;
	}

	// Metodo per eseguire query di tipo SELECT
	public static ResultSet selectQuery(String query) throws SQLException {
		Connection conn = getConnection();
		Statement statement = conn.createStatement();
		System.out.println("Eseguo SELECT: " + query);
		return statement.executeQuery(query);
		// ATTENZIONE: la connessione e lo statement devono essere chiusi da chi riceve il ResultSet!
	}

	// Metodo per eseguire UPDATE, INSERT, DELETE
	public static int updateQuery(String query) throws SQLException {
		try (Connection conn = getConnection();
			 Statement statement = conn.createStatement()) {

			System.out.println("Eseguo UPDATE: " + query);
			int result = statement.executeUpdate(query);
			System.out.println("Righe modificate: " + result);
			return result;
		}
	}

	// Metodo di utilità per chiudere connessione, statement e resultset
	public static void closeResources(Connection conn, Statement stmt, ResultSet rs) {
		try {
			if (rs != null && !rs.isClosed()) rs.close();
		} catch (SQLException e) { e.printStackTrace(); }
		try {
			if (stmt != null && !stmt.isClosed()) stmt.close();
		} catch (SQLException e) { e.printStackTrace(); }
		try {
			if (conn != null && !conn.isClosed()) conn.close();
		} catch (SQLException e) { e.printStackTrace(); }
	}
}
